import React, { useRef } from "react";
import useLayoutEffect from "../utils/useIsomorphicLayoutEffect";
import { useDarkMode } from "next-dark-mode";

import { generateChartData } from "../utils/generateChartData";

import {
  generatePieChart,
  generateLineChart,
  generateColumnChart,
  generateStockChart,
  generateClusteredColumnChart,
  generateDrillDownPieChart,
  generateExplodingPieChart,
  generateDivergentLineChart,
  generateBubbleChart,
  generateCandleStockChart,
} from "../utils/generateChart";

const radarData = require("../data/radar.json");

export default function Widget({ identifier, widgetSize, title, chartType }) {
  const chart = useRef(null);
  const { darkModeActive } = useDarkMode();

  useLayoutEffect(() => {
    let x = null;

    switch (chartType) {
      case "pie":
        x = generatePieChart(identifier, radarData.data);
        break;
      case "line":
        x = generateLineChart(identifier, radarData.data);
        break;
      case "column":
        x = generateColumnChart(identifier, radarData.data);
        break;
      case "stock":
        x = generateStockChart(identifier, generateChartData());
        break;
      case "clusteredColumn":
        x = generateClusteredColumnChart(identifier, {});
        break;
      case "drilldownPie":
        x = generateDrillDownPieChart(identifier, {});
        break;
      case "explodingPie":
        x = generateExplodingPieChart(identifier, {});
        break;
      case "divergentLine":
        x = generateDivergentLineChart(identifier, {});
        break;
      case "bubble":
        x = generateBubbleChart(identifier, {});
        break;
      case "candle":
        x = generateCandleStockChart(identifier, {});
        break;
      default:
        break;
    }

    chart.current = x;

    return () => {
      x.dispose();
    };
  }, [darkModeActive]);

  return (
    <div
      className={`w-full shadow h-96 min-h-full lg:w-${widgetSize} p-4 border border-gray-100 rounded-md bg-white dark:bg-gray-900 dark:border-transparent`}
    >
      <div className="flex flex-row items-center justify-between mb-4">
        <span className="font-bold text-lg text-black dark:text-white">
          {title}
        </span>
      </div>
      <div
        id={identifier}
        className="flex flex-row"
        style={{
          width: "90%",
          height: "90%",
        }}
      ></div>
    </div>
  );
}
