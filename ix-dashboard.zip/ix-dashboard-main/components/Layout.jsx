import { useState, useEffect } from "react";
import { useDarkMode } from "next-dark-mode";
import { motion, AnimatePresence } from "framer-motion";

import {
  am4themes_ixThemeLight,
  am4themes_ixThemeDark,
} from "../styles/chartTheme";

let am4core = null;
let am4charts = null;
let am4themesAnimated = null;

if (process.browser) {
  am4core = require("@amcharts/amcharts4/core");
  am4charts = require("@amcharts/amcharts4/charts");
  // TODO: Can improve performance, but need to investigate why some widgets were staying blank
  //   am4core.options.onlyShowOnViewport = true;
}

export default function Layout(props) {
  const [darkMode, setDarkMode] = useState(false);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);
  const [hamburgerOpen, setHamburgerOpen] = useState(false);

  const { darkModeActive, switchToDarkMode, switchToLightMode } = useDarkMode();

  return (
    <div className={`transition-colors ${darkModeActive ? "dark" : ""}`}>
      <div class="h-screen flex overflow-hidden bg-gray-100 dark:bg-gray-900 transition-colors">
        <MobileSiderbar
          hamburgerOpen={hamburgerOpen}
          didClickClose={() => setHamburgerOpen(false)}
        />
        <Sidebar />
        <div class="flex flex-col w-0 flex-1 overflow-hidden">
          <div class="md:hidden pl-1 pt-1 sm:pl-3 sm:pt-3">
            <button
              onClick={() => setHamburgerOpen(true)}
              class="-ml-0.5 -mt-0.5 h-12 w-12 inline-flex items-center justify-center rounded-md text-gray-500 hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500"
            >
              <span class="sr-only">Open sidebar</span>
              {/* <!-- Heroicon name: menu --> */}
              <svg
                class="h-6 w-6"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                aria-hidden="true"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M4 6h16M4 12h16M4 18h16"
                />
              </svg>
            </button>
          </div>
          <main
            class="flex-1 relative z-0 overflow-y-auto focus:outline-none"
            tabindex="0"
          >
            <div class="bg-gray-50 dark:bg-gray-800 py-6">
              <div className="flex sm:flex-col flex-row justify-center pb-8">
                <div className="self-center">
                  <Logo />
                </div>
              </div>
              <div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 flex md:flex-row flex-col justify-between align-items-center">
                <h1 class="text-2xl md:text-xl pt-4 md:text-left text-center sm:text-lg font-medium text-gray-900 dark:text-gray-50">
                  December 2020 Report, Point72
                </h1>
                <div className="flex flex-row text-md font-medium order-first md:order-last self-center">
                  <button
                    type="button"
                    aria-pressed="false"
                    className={`${
                      darkModeActive
                        ? "bg-orange"
                        : "bg-gray-200 dark:bg-gray-800"
                    } relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange`}
                    onClick={() => {
                      if (darkModeActive) {
                        am4core.unuseTheme(am4themes_ixThemeDark);
                        am4core.useTheme(am4themes_ixThemeLight);
                        switchToLightMode();
                      } else {
                        am4core.unuseTheme(am4themes_ixThemeLight);
                        am4core.useTheme(am4themes_ixThemeDark);
                        switchToDarkMode();
                      }
                    }}
                  >
                    <span className="sr-only">Dark Mode</span>
                    <span
                      aria-hidden="true"
                      className={`${
                        darkModeActive ? "translate-x-5" : "translate-x-0"
                      } inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200`}
                    ></span>
                  </button>
                  <span className="pl-4 text-gray-700 dark:text-gray-200">
                    Toggle Dark Mode
                  </span>
                </div>
              </div>
              <div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
                {props.children}
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}

function Sidebar(props) {
  const [collapsed, setCollapsed] = useState(true);
  const { darkModeActive } = useDarkMode();

  return (
    <div class="hidden md:flex md:flex-shrink-0">
      <div class={`flex flex-col ${collapsed ? "w-16" : "w-64"}`}>
        {/* <!-- Sidebar component, swap this element with another sidebar if you like --> */}
        <div class="flex flex-col h-0 flex-1 border-r border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 ">
          <div class="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
            <div
              onClick={() => {
                setCollapsed(!collapsed);
              }}
              class="flex items-center flex-shrink-0 px-4"
            >
              <Logo collapsed={collapsed} />
            </div>
            <nav class="mt-5 flex-1 px-2 bg-white dark:bg-gray-900 space-y-1">
              <SidebarMenuItem
                icon={
                  <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"
                  />
                }
                title="Dashboard"
                collapsed={collapsed}
                selected={true}
              />
              <SidebarMenuItem
                icon={
                  <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                  />
                }
                title="Calendar"
                collapsed={collapsed}
                selected={false}
              />
              <SidebarMenuItem
                icon={
                  <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"
                  />
                }
                title="Documents"
                collapsed={collapsed}
                selected={false}
              />
            </nav>
          </div>
          <div class="flex-shrink-0 flex border-t border-gray-200 p-4">
            <a href="#" class="flex-shrink-0 w-full group block">
              <div class="flex items-center">
                <div>
                  <img
                    className="inline-block h-9 w-9 object-contain"
                    src={
                      darkModeActive
                        ? "p72_small_darkmode.png"
                        : "p72_small_darkmode.png"
                    } // : (darkModeActive ? "p72_full_darkmode.png" : "p72_full_lightmode.png")}
                    alt=""
                  />
                </div>
                {!collapsed && (
                  <div class="ml-3">
                    <p class="text-sm font-medium text-gray-700 dark:text-gray-100 group-hover:text-gray-900 dark:group-hover:text-gray-50">
                      Point72
                    </p>
                    <p class="text-xs font-medium text-gray-500 dark:text-gray-300 group-hover:text-gray-700 dark:group-hover:text-gray-200">
                      View profile
                    </p>
                  </div>
                )}
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

function SidebarMenuItem({ icon, title, collapsed, selected }) {
  return (
    <a
      href="#"
      class={`${
        selected
          ? "dark:bg-gray-800 dark:text-gray-50 bg-gray-100 text-gray-900"
          : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
      } group flex items-center px-2 py-2 text-sm font-medium rounded-md dark:hover:text-gray-100 hover:text-gray-900 hover:bg-gray-100 dark:hover:bg-gray-800`}
    >
      <svg
        class={`text-gray-500 ${collapsed ? "mr-0" : "mr-3"} h-6 w-6`}
        xmlns="http://www.w3.org/2000/svg"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        aria-hidden="true"
      >
        {icon}
      </svg>
      {!collapsed && <>{title}</>}
    </a>
  );
}

function MobileSiderbar(props) {
  return (
    <AnimatePresence initial={false}>
      <div class="md:hidden" hidden={!props.hamburgerOpen}>
        <motion.div
          key={"mobileSidebar"}
          initial={{ translateX: 0, transition: 0.2 }}
          animate={{ translateX: 0, transition: 0.2 }}
          exit={{ translateX: -200, transition: 0.2 }}
        >
          <div class="fixed inset-0 flex z-40">
            {/* <!--
            Off-canvas menu overlay, show/hide based on off-canvas menu state.
    
            Entering: "transition-opacity ease-linear duration-300"
              From: "opacity-0"
              To: "opacity-100"
            Leaving: "transition-opacity ease-linear duration-300"
              From: "opacity-100"
              To: "opacity-0"
          --> */}
            <div class="fixed inset-0">
              <div class="absolute inset-0 bg-gray-600 dark:bg-gray-300 opacity-75"></div>
            </div>
            {/* <!--
            Off-canvas menu, show/hide based on off-canvas menu state.
    
            Entering: "transition ease-in-out duration-300 transform"
              From: "-translate-x-full"
              To: "translate-x-0"
            Leaving: "transition ease-in-out duration-300 transform"
              From: "translate-x-0"
              To: "-translate-x-full"
          --> */}
            <div class="relative flex-1 flex flex-col max-w-xs w-full bg-white dark:bg-gray-900">
              <div class="absolute top-0 right-0 -mr-12 pt-2">
                <button
                  onClick={props.didClickClose}
                  class="ml-1 flex items-center justify-center h-10 w-10 rounded-full focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
                >
                  <span class="sr-only">Close sidebar</span>
                  {/* <!-- Heroicon name: x --> */}
                  <svg
                    class="h-6 w-6 text-white dark:text-black"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    aria-hidden="true"
                  >
                    <path
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      stroke-width="2"
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </div>
              <div class="flex-1 h-0 pt-5 pb-4 overflow-y-auto">
                <div class="flex-shrink-0 flex items-center px-4 mr-16">
                  <Logo />
                </div>
                <nav class="mt-5 px-2 space-y-1">
                  {/* <!-- Current: "bg-gray-100 text-gray-900", Default: "text-gray-600 hover:bg-gray-50 hover:text-gray-900" --> */}
                  <a
                    href="#"
                    class="bg-gray-100 text-gray-900 group flex items-center px-2 py-2 text-base font-medium rounded-md"
                  >
                    {/* <!-- Current: "text-gray-500", Default: "text-gray-400 group-hover:text-gray-500" --> */}
                    {/* <!-- Heroicon name: home --> */}
                    <svg
                      class="text-gray-500 mr-4 h-6 w-6"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      aria-hidden="true"
                    >
                      <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"
                      />
                    </svg>
                    Dashboard
                  </a>
                  <a
                    href="#"
                    class="text-gray-600 hover:bg-gray-50 hover:text-gray-900 group flex items-center px-2 py-2 text-base font-medium rounded-md"
                  >
                    {/* <!-- Heroicon name: calendar --> */}
                    <svg
                      class="text-gray-400 group-hover:text-gray-500 mr-4 h-6 w-6"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      aria-hidden="true"
                    >
                      <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                      />
                    </svg>
                    Calendar
                  </a>

                  <a
                    href="#"
                    class="text-gray-600 hover:bg-gray-50 hover:text-gray-900 group flex items-center px-2 py-2 text-base font-medium rounded-md"
                  >
                    {/* <!-- Heroicon name: inbox --> */}
                    <svg
                      class="text-gray-400 group-hover:text-gray-500 mr-4 h-6 w-6"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      aria-hidden="true"
                    >
                      <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"
                      />
                    </svg>
                    Documents
                  </a>
                </nav>
              </div>
              <div class="flex-shrink-0 flex border-t border-gray-200 dark:border-gray-700 p-4">
                <a href="#" class="flex-shrink-0 group block">
                  <div class="flex items-center">
                    <div>
                      <img
                        className="inline-block h-10 w-10 rounded-full"
                        src="p72_small_darkmode.png"
                        alt=""
                      />
                    </div>
                    <div class="ml-3">
                      <p class="text-base font-medium text-gray-700 group-hover:text-gray-900">
                        Tom Cook
                      </p>
                      <p class="text-sm font-medium text-gray-500 group-hover:text-gray-700">
                        View profile
                      </p>
                    </div>
                  </div>
                </a>
              </div>
            </div>
            <div class="flex-shrink-0 w-14">
              {/* <!-- Force sidebar to shrink to fit close icon --> */}
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}

function Logo({ collapsed }) {
  const { darkModeActive } = useDarkMode();

  const fill = darkModeActive ? "white" : "black";

  if (collapsed) {
    return (
      <svg
        width="80"
        height="64"
        viewBox="0 0 225 186"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M11.5801 60.0001L40.2201 26.3901"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M48.6299 21.0801L105.74 5.8501"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M149.7 7.7701L105.74 5.8501"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M186.28 27.6303L159.32 10.7603"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M204.94 46.9699L186.28 27.6299"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M222.12 91.0599L210.22 55.6499"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M206.86 107.81L222.12 91.0601"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M190.53 150.32L201.71 116.6"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M160.9 174.25L190.53 150.32"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M109.79 136.83L152.92 174.11"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M75.9004 136.3L100.54 133.85"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M54.0098 114.63L75.8998 136.3"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M31.0098 110.39L54.0098 114.63"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M10.0801 68.8101L23.9201 104.57"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M29.8496 106.16L76.2096 68.7603"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M46.9697 26.3901L76.8897 61.5301"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M150.78 11.1699L84.3799 62.3199"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M149.17 76.0903L142.69 104.35"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M203.641 52.4199L155.561 69.0799"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M84.5898 68.6001L137.3 106.39"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M154.53 13.2002L150.74 65.6802"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M155.75 172.61L142.67 114.5"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M199.23 108.48L154.48 74.0601"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M43.53 27.0702C46.33 27.0702 48.6 24.8003 48.6 22.0002C48.6 19.2001 46.33 16.9302 43.53 16.9302C40.7299 16.9302 38.46 19.2001 38.46 22.0002C38.46 24.8003 40.7299 27.0702 43.53 27.0702Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M80.2604 70.1302C83.0605 70.1302 85.3304 67.8603 85.3304 65.0602C85.3304 62.2601 83.0605 59.9902 80.2604 59.9902C77.4603 59.9902 75.1904 62.2601 75.1904 65.0602C75.1904 67.8603 77.4603 70.1302 80.2604 70.1302Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M149.92 76.4701C152.72 76.4701 154.99 74.2002 154.99 71.4001C154.99 68.6 152.72 66.3301 149.92 66.3301C147.12 66.3301 144.85 68.6 144.85 71.4001C144.85 74.2002 147.12 76.4701 149.92 76.4701Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M141.06 114.46C143.86 114.46 146.13 112.19 146.13 109.39C146.13 106.59 143.86 104.32 141.06 104.32C138.26 104.32 135.99 106.59 135.99 109.39C135.99 112.19 138.26 114.46 141.06 114.46Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M154.99 13.14C157.79 13.14 160.06 10.8701 160.06 8.07C160.06 5.26992 157.79 3 154.99 3C152.19 3 149.92 5.26992 149.92 8.07C149.92 10.8701 152.19 13.14 154.99 13.14Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M208.19 56.2001C210.99 56.2001 213.26 53.9301 213.26 51.1301C213.26 48.33 210.99 46.0601 208.19 46.0601C205.39 46.0601 203.12 48.33 203.12 51.1301C203.12 53.9301 205.39 56.2001 208.19 56.2001Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M203.12 117C205.92 117 208.19 114.73 208.19 111.93C208.19 109.13 205.92 106.86 203.12 106.86C200.32 106.86 198.05 109.13 198.05 111.93C198.05 114.73 200.32 117 203.12 117Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M156.26 182.86C159.061 182.86 161.33 180.59 161.33 177.79C161.33 174.99 159.061 172.72 156.26 172.72C153.46 172.72 151.19 174.99 151.19 177.79C151.19 180.59 153.46 182.86 156.26 182.86Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M105.59 138.53C108.39 138.53 110.66 136.26 110.66 133.46C110.66 130.66 108.39 128.39 105.59 128.39C102.789 128.39 100.52 130.66 100.52 133.46C100.52 136.26 102.789 138.53 105.59 138.53Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M25.8005 114.46C28.6006 114.46 30.8705 112.19 30.8705 109.39C30.8705 106.59 28.6006 104.32 25.8005 104.32C23.0004 104.32 20.7305 106.59 20.7305 109.39C20.7305 112.19 23.0004 114.46 25.8005 114.46Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M8.07 68.87C10.8701 68.87 13.14 66.6001 13.14 63.8C13.14 60.9999 10.8701 58.73 8.07 58.73C5.26992 58.73 3 60.9999 3 63.8C3 66.6001 5.26992 68.87 8.07 68.87Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
      </svg>
    );
  } else {
    return (
      <svg
        width="293"
        height="37"
        viewBox="0 0 1465 186"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M1139.03 116.95C1135.96 121.068 1132 124.433 1127.44 126.79C1122.69 129.303 1116.99 130.56 1110.33 130.56C1104.89 130.619 1099.49 129.628 1094.43 127.64C1089.73 125.794 1085.46 123.007 1081.88 119.45C1078.32 115.863 1075.52 111.599 1073.64 106.91C1071.61 101.823 1070.59 96.3876 1070.64 90.9097C1070.56 85.3938 1071.58 79.9175 1073.64 74.7997C1075.54 70.1157 1078.4 65.8792 1082.03 62.3597C1085.7 58.8803 1090.02 56.1614 1094.74 54.3597C1099.84 52.4008 1105.27 51.4269 1110.74 51.4897C1113.34 51.4913 1115.94 51.7391 1118.5 52.2297C1121.09 52.7172 1123.61 53.4643 1126.05 54.4597C1128.39 55.4154 1130.6 56.6475 1132.64 58.1297C1134.59 59.5292 1136.31 61.2149 1137.75 63.1297L1129.5 69.4997C1127.45 66.7828 1124.77 64.6093 1121.69 63.1697C1118.3 61.5044 1114.57 60.6519 1110.79 60.6797C1106.71 60.6111 1102.66 61.4265 1098.93 63.0697C1095.5 64.5951 1092.44 66.8232 1089.93 69.6097C1087.42 72.4191 1085.47 75.685 1084.19 79.2297C1082.83 82.9594 1082.16 86.9015 1082.19 90.8697C1082.16 94.9256 1082.84 98.9555 1084.19 102.78C1085.42 106.325 1087.33 109.594 1089.82 112.4C1092.3 115.159 1095.35 117.355 1098.75 118.84C1102.46 120.44 1106.46 121.237 1110.5 121.18C1114.51 121.236 1118.48 120.359 1122.09 118.62C1125.55 116.925 1128.52 114.362 1130.7 111.18L1139.03 116.95Z"
          fill={fill}
        />
        <path
          d="M1173.59 128.65H1163.06V53.37H1187.2C1190.67 53.3566 1194.12 53.7357 1197.5 54.5C1200.55 55.1512 1203.45 56.358 1206.06 58.06C1208.5 59.6819 1210.5 61.8934 1211.86 64.49C1213.35 67.5104 1214.08 70.8519 1213.98 74.22C1213.98 79.7533 1212.28 84.22 1208.88 87.62C1205.28 91.1201 1200.66 93.3888 1195.69 94.1L1216.75 128.66H1204L1184.86 95.17H1173.59V128.65ZM1173.59 86.33H1185.71C1188.03 86.3467 1190.34 86.1323 1192.62 85.69C1194.59 85.3313 1196.48 84.6307 1198.2 83.62C1200.6 82.0272 1202.32 79.5958 1203.02 76.8024C1203.72 74.009 1203.35 71.0551 1201.98 68.52C1201.08 67.015 1199.82 65.7549 1198.31 64.85C1196.65 63.8681 1194.84 63.1908 1192.94 62.85C1190.8 62.4508 1188.63 62.2533 1186.45 62.26H1173.59V86.33Z"
          fill={fill}
        />
        <path
          d="M1317.56 90.8998C1317.63 96.3794 1316.61 101.818 1314.56 106.9C1312.64 111.595 1309.8 115.858 1306.21 119.44C1302.59 122.997 1298.29 125.783 1293.56 127.63C1283.3 131.523 1271.97 131.523 1261.71 127.63C1257 125.773 1252.72 122.987 1249.11 119.44C1245.52 115.866 1242.7 111.599 1240.82 106.9C1238.78 101.814 1237.76 96.3781 1237.82 90.8998C1237.76 85.3852 1238.78 79.9117 1240.82 74.7898C1242.69 70.1114 1245.51 65.8743 1249.11 62.3498C1252.74 58.8745 1257.02 56.1552 1261.71 54.3498C1271.98 50.5234 1283.29 50.5234 1293.56 54.3498C1298.27 56.1449 1302.57 58.8651 1306.21 62.3498C1309.79 65.8876 1312.61 70.1211 1314.5 74.7898C1316.58 79.9034 1317.62 85.3799 1317.56 90.8998ZM1306.18 90.8998C1306.21 86.932 1305.53 82.9908 1304.18 79.2598C1302.9 75.7169 1300.95 72.4517 1298.44 69.6398C1295.93 66.8543 1292.86 64.6263 1289.44 63.0998C1285.71 61.5222 1281.69 60.7094 1277.64 60.7094C1273.59 60.7094 1269.57 61.5222 1265.84 63.0998C1262.43 64.6155 1259.38 66.8457 1256.91 69.6398C1254.42 72.4592 1252.49 75.7232 1251.22 79.2598C1249.86 82.9895 1249.19 86.9316 1249.22 90.8998C1249.18 94.9237 1249.86 98.9221 1251.22 102.71C1252.49 106.261 1254.44 109.53 1256.96 112.33C1259.46 115.07 1262.5 117.26 1265.89 118.76C1269.58 120.364 1273.57 121.162 1277.59 121.1C1281.64 121.153 1285.66 120.356 1289.39 118.76C1292.81 117.272 1295.87 115.081 1298.39 112.33C1300.91 109.527 1302.86 106.259 1304.13 102.71C1305.5 98.9239 1306.2 94.9263 1306.18 90.8998Z"
          fill={fill}
        />
        <path
          d="M1382.63 67.2999C1381.03 65.1763 1378.96 63.4625 1376.57 62.2999C1373.9 60.951 1370.95 60.265 1367.96 60.2999C1366.22 60.3041 1364.48 60.536 1362.8 60.9899C1361.1 61.434 1359.49 62.1901 1358.07 63.2199C1356.66 64.2406 1355.48 65.5453 1354.61 67.0499C1353.68 68.7247 1353.23 70.6171 1353.28 72.5299C1353.22 74.3279 1353.64 76.1095 1354.5 77.6899C1355.33 79.0835 1356.46 80.2782 1357.8 81.1899C1359.31 82.2193 1360.96 83.0432 1362.69 83.6399C1364.57 84.3065 1366.57 84.9965 1368.69 85.7099C1371.24 86.4899 1373.83 87.3765 1376.45 88.3699C1379.01 89.3271 1381.41 90.6546 1383.58 92.3099C1385.72 93.9615 1387.5 96.0426 1388.79 98.4199C1390.23 101.303 1390.91 104.501 1390.79 107.72C1390.87 111.231 1390.13 114.712 1388.61 117.88C1387.23 120.654 1385.25 123.086 1382.81 125C1380.32 126.921 1377.49 128.347 1374.46 129.2C1371.3 130.122 1368.02 130.586 1364.73 130.58C1360.01 130.584 1355.33 129.646 1350.97 127.82C1346.66 126.073 1342.88 123.253 1339.97 119.63L1348.16 112.72C1350.04 115.44 1352.55 117.665 1355.47 119.203C1358.4 120.741 1361.65 121.546 1364.96 121.55C1366.76 121.546 1368.54 121.294 1370.27 120.8C1372.01 120.322 1373.65 119.529 1375.11 118.46C1376.56 117.392 1377.78 116.029 1378.67 114.46C1379.64 112.683 1380.12 110.682 1380.06 108.66C1380.13 106.665 1379.63 104.691 1378.62 102.97C1377.62 101.409 1376.3 100.085 1374.74 99.0899C1372.96 97.9562 1371.05 97.046 1369.05 96.3799C1366.89 95.6332 1364.6 94.8699 1362.19 94.0899C1359.76 93.3765 1357.38 92.5081 1355.07 91.4899C1352.79 90.5011 1350.68 89.1727 1348.8 87.5499C1346.92 85.9141 1345.39 83.905 1344.33 81.6499C1343.12 78.9074 1342.54 75.9272 1342.63 72.9299C1342.54 69.5631 1343.32 66.2301 1344.91 63.2599C1346.4 60.6153 1348.44 58.3284 1350.91 56.5599C1353.41 54.763 1356.22 53.4472 1359.2 52.6799C1362.24 51.8843 1365.36 51.4876 1368.5 51.4999C1372.72 51.4697 1376.91 52.2611 1380.83 53.8299C1384.35 55.1852 1387.52 57.334 1390.08 60.1099L1382.63 67.2999Z"
          fill={fill}
        />
        <path
          d="M1456.42 67.2998C1454.82 65.1763 1452.75 63.4625 1450.36 62.2998C1447.69 60.9509 1444.73 60.2649 1441.74 60.2998C1440 60.3049 1438.27 60.5369 1436.59 60.9898C1434.89 61.4339 1433.28 62.1901 1431.86 63.2198C1430.45 64.2405 1429.27 65.5453 1428.4 67.0498C1427.47 68.7247 1427.01 70.6171 1427.07 72.5298C1427.01 74.3279 1427.43 76.1095 1428.29 77.6898C1429.12 79.0835 1430.25 80.2781 1431.59 81.1898C1433.1 82.2193 1434.75 83.0431 1436.48 83.6398C1438.36 84.3065 1440.36 84.9965 1442.48 85.7098C1445.03 86.4898 1447.62 87.3765 1450.24 88.3698C1452.79 89.3251 1455.19 90.6528 1457.36 92.3098C1459.74 94.0826 1461.65 96.4174 1462.91 99.1062C1464.17 101.795 1464.75 104.754 1464.59 107.72C1464.68 111.23 1463.93 114.711 1462.42 117.88C1461.04 120.654 1459.06 123.086 1456.62 125C1454.13 126.921 1451.3 128.347 1448.27 129.2C1445.11 130.122 1441.83 130.586 1438.54 130.58C1433.81 130.584 1429.13 129.646 1424.77 127.82C1420.47 126.071 1416.68 123.252 1413.77 119.63L1421.96 112.72C1423.84 115.44 1426.35 117.665 1429.27 119.203C1432.2 120.741 1435.45 121.546 1438.76 121.55C1440.56 121.546 1442.34 121.294 1444.07 120.8C1445.81 120.32 1447.45 119.527 1448.91 118.46C1450.36 117.391 1451.58 116.029 1452.47 114.46C1453.44 112.683 1453.92 110.682 1453.86 108.66C1453.93 106.665 1453.43 104.691 1452.42 102.97C1451.42 101.409 1450.1 100.085 1448.54 99.0898C1446.76 97.9562 1444.85 97.046 1442.85 96.3798C1440.69 95.6331 1438.4 94.8698 1435.99 94.0898C1433.56 93.3765 1431.18 92.508 1428.87 91.4898C1426.59 90.4987 1424.47 89.1705 1422.59 87.5498C1420.71 85.9113 1419.19 83.9026 1418.13 81.6498C1416.92 78.9074 1416.34 75.9272 1416.43 72.9298C1416.34 69.5631 1417.12 66.2301 1418.71 63.2598C1420.2 60.6153 1422.24 58.3284 1424.71 56.5598C1427.21 54.7611 1430.02 53.4452 1433 52.6798C1436.04 51.8699 1439.17 51.4598 1442.31 51.4598C1446.53 51.4297 1450.72 52.221 1454.64 53.7898C1458.16 55.1451 1461.33 57.294 1463.89 60.0698L1456.42 67.2998Z"
          fill={fill}
        />
        <path d="M295.5 128.65V53.3701H313.79V128.65H295.5Z" fill={fill} />
        <path
          d="M385.13 128.65L354.83 79.4201H354.5L354.92 128.65H337.28V53.3701H358.02L388.21 102.5H388.5L388.08 53.3801H405.73V128.66L385.13 128.65Z"
          fill={fill}
        />
        <path
          d="M461.5 68.8901V128.65H443.29V68.8901H422.02V53.3701H482.74V68.8901H461.5Z"
          fill={fill}
        />
        <path
          d="M499 128.65V53.3701H549.62V68.6801H516.55V82.9301H547.81V97.5001H516.55V113.13H551.55V128.65H499Z"
          fill={fill}
        />
        <path
          d="M571.5 128.65V53.3701H589.79V112.81H618.92V128.65H571.5Z"
          fill={fill}
        />
        <path
          d="M635.42 128.65V53.3701H653.71V112.81H682.84V128.65H635.42Z"
          fill={fill}
        />
        <path d="M699.32 128.65V53.3701H717.61V128.65H699.32Z" fill={fill} />
        <path
          d="M795.07 128.76C789.791 130 784.382 130.605 778.96 130.56C773.284 130.625 767.645 129.652 762.32 127.69C757.457 125.91 753.007 123.162 749.24 119.61C745.554 116.083 742.639 111.83 740.68 107.12C738.572 101.976 737.525 96.4589 737.6 90.9C737.513 85.2761 738.582 79.6942 740.74 74.5C742.71 69.7681 745.662 65.5078 749.4 62C753.165 58.5246 757.584 55.8324 762.4 54.08C767.545 52.2083 772.984 51.2735 778.46 51.32C784.101 51.2671 789.709 52.1838 795.04 54.03C799.662 55.5604 803.909 58.0516 807.5 61.34L795.97 74.42C794.029 72.2627 791.64 70.5561 788.97 69.42C785.857 68.055 782.488 67.373 779.09 67.42C776.056 67.3897 773.05 67.989 770.26 69.18C767.621 70.3218 765.24 71.9851 763.26 74.07C761.229 76.2133 759.645 78.739 758.6 81.5C757.475 84.5085 756.916 87.6986 756.95 90.91C756.915 94.1604 757.418 97.3941 758.44 100.48C759.357 103.267 760.86 105.824 762.85 107.98C764.873 110.12 767.341 111.789 770.08 112.87C773.215 114.087 776.557 114.681 779.92 114.62C781.949 114.63 783.976 114.473 785.98 114.15C787.806 113.853 789.59 113.332 791.29 112.6V98.88H776.94V84.2H807.94V124.08C803.848 126.139 799.528 127.709 795.07 128.76Z"
          fill={fill}
        />
        <path
          d="M830.85 128.65V53.3701H881.5V68.6801H848.39V82.9301H879.65V97.5001H848.39V113.13H883.39V128.65H830.85Z"
          fill={fill}
        />
        <path
          d="M951.21 128.65L920.91 79.4201H920.59L921.01 128.65H903.36V53.3701H924.1L954.29 102.5H954.61L954.19 53.3801H971.84V128.66L951.21 128.65Z"
          fill={fill}
        />
        <path
          d="M1027.55 68.8901V128.65H1009.37V68.8901H988.1V53.3701H1048.82V68.8901H1027.55Z"
          fill={fill}
        />
        <path
          d="M11.5801 60.0001L40.2201 26.3901"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M48.6299 21.0801L105.74 5.8501"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M149.7 7.7701L105.74 5.8501"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M186.28 27.6303L159.32 10.7603"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M204.94 46.9699L186.28 27.6299"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M222.12 91.0599L210.22 55.6499"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M206.86 107.81L222.12 91.0601"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M190.53 150.32L201.71 116.6"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M160.9 174.25L190.53 150.32"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M109.79 136.83L152.92 174.11"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M75.9004 136.3L100.54 133.85"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M54.0098 114.63L75.8998 136.3"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M31.0098 110.39L54.0098 114.63"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M10.0801 68.8101L23.9201 104.57"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M29.8496 106.16L76.2096 68.7603"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M46.9697 26.3901L76.8897 61.5301"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M150.78 11.1699L84.3799 62.3199"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M149.17 76.0903L142.69 104.35"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M203.641 52.4199L155.561 69.0799"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M84.5898 68.6001L137.3 106.39"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M154.53 13.2002L150.74 65.6802"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M155.75 172.61L142.67 114.5"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M199.23 108.48L154.48 74.0601"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M43.53 27.0702C46.33 27.0702 48.6 24.8003 48.6 22.0002C48.6 19.2001 46.33 16.9302 43.53 16.9302C40.7299 16.9302 38.46 19.2001 38.46 22.0002C38.46 24.8003 40.7299 27.0702 43.53 27.0702Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M80.2604 70.1302C83.0605 70.1302 85.3304 67.8603 85.3304 65.0602C85.3304 62.2601 83.0605 59.9902 80.2604 59.9902C77.4603 59.9902 75.1904 62.2601 75.1904 65.0602C75.1904 67.8603 77.4603 70.1302 80.2604 70.1302Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M149.92 76.4701C152.72 76.4701 154.99 74.2002 154.99 71.4001C154.99 68.6 152.72 66.3301 149.92 66.3301C147.12 66.3301 144.85 68.6 144.85 71.4001C144.85 74.2002 147.12 76.4701 149.92 76.4701Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M141.06 114.46C143.86 114.46 146.13 112.19 146.13 109.39C146.13 106.59 143.86 104.32 141.06 104.32C138.26 104.32 135.99 106.59 135.99 109.39C135.99 112.19 138.26 114.46 141.06 114.46Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M154.99 13.14C157.79 13.14 160.06 10.8701 160.06 8.07C160.06 5.26992 157.79 3 154.99 3C152.19 3 149.92 5.26992 149.92 8.07C149.92 10.8701 152.19 13.14 154.99 13.14Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M208.19 56.2001C210.99 56.2001 213.26 53.9301 213.26 51.1301C213.26 48.33 210.99 46.0601 208.19 46.0601C205.39 46.0601 203.12 48.33 203.12 51.1301C203.12 53.9301 205.39 56.2001 208.19 56.2001Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M203.12 117C205.92 117 208.19 114.73 208.19 111.93C208.19 109.13 205.92 106.86 203.12 106.86C200.32 106.86 198.05 109.13 198.05 111.93C198.05 114.73 200.32 117 203.12 117Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M156.26 182.86C159.061 182.86 161.33 180.59 161.33 177.79C161.33 174.99 159.061 172.72 156.26 172.72C153.46 172.72 151.19 174.99 151.19 177.79C151.19 180.59 153.46 182.86 156.26 182.86Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M105.59 138.53C108.39 138.53 110.66 136.26 110.66 133.46C110.66 130.66 108.39 128.39 105.59 128.39C102.789 128.39 100.52 130.66 100.52 133.46C100.52 136.26 102.789 138.53 105.59 138.53Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M25.8005 114.46C28.6006 114.46 30.8705 112.19 30.8705 109.39C30.8705 106.59 28.6006 104.32 25.8005 104.32C23.0004 104.32 20.7305 106.59 20.7305 109.39C20.7305 112.19 23.0004 114.46 25.8005 114.46Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
        <path
          d="M8.07 68.87C10.8701 68.87 13.14 66.6001 13.14 63.8C13.14 60.9999 10.8701 58.73 8.07 58.73C5.26992 58.73 3 60.9999 3 63.8C3 66.6001 5.26992 68.87 8.07 68.87Z"
          stroke={fill}
          stroke-width="5"
          stroke-miterlimit="10"
        />
      </svg>
    );
  }
}
