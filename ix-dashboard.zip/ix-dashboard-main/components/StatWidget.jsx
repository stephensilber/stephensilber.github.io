import React from "react";

export default function StatWidget({
  title,
  subtitle,
  value,
  previousValue,
  delta,
  selected,
  onClick,
}) {
  return (
    <div
      onClick={onClick}
      className={`bg-white dark:bg-gray-900 rounded-md shadow hover:shadow-lg active:shadow-md cursor-pointer border-2 box-border transition-all ${
        selected
          ? "shadow-lg border-orange"
          : "border-white dark:border-gray-900"
      }`}
    >
      <div class="px-4 py-5 sm:p-4">
        <dt class="text-base font-normal text-gray-900 dark:text-gray-100">
          {title}
        </dt>
        <dd class="mt-1 flex lg:flex-row md:flex-col justify-between items-baseline sm:block md:flex">
          <div class="flex items-baseline text-2xl font-semibold text-orange">
            {value}
            <span class="ml-2 text-sm font-medium text-gray-500 dark:text-gray-400">
              from {previousValue}
            </span>
          </div>

          <div class="inline-flex items-baseline px-2.5 py-0.5 rounded-full text-sm font-medium bg-green-100 text-green-800 md:mt-2 lg:mt-0">
            <svg
              class="-ml-1 mr-0.5 flex-shrink-0 self-center h-5 w-5 text-green-500"
              fill="currentColor"
              viewBox="0 0 20 20"
              aria-hidden="true"
            >
              <path
                fill-rule="evenodd"
                d="M5.293 9.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 7.414V15a1 1 0 11-2 0V7.414L6.707 9.707a1 1 0 01-1.414 0z"
                clip-rule="evenodd"
              />
            </svg>
            <span class="sr-only">Increased by</span>
            12%
          </div>
        </dd>
        <dd class={`mt-2 ml-auto mr-auto w-6 h-6 text-gray-400 dark:text-gray-200 transition-all ${selected ? "transform rotate-180" : "transform rotate-0"}`}>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M19 9l-7 7-7-7"
            />
          </svg>
        </dd>
      </div>
    </div>
  );
}
