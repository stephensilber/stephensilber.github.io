let am4core = null;
let am4charts = null;

if (process.browser) {
  am4core = require("@amcharts/amcharts4/core");
  am4charts = require("@amcharts/amcharts4/charts");
}

export function am4themes_ixThemeLight(target) {
  if (target instanceof am4core.ColorSet) {
    target.list = [
      am4core.color("#FF6C0C"),
      am4core.color("#BF5109"),
      am4core.color("#FF893D"),
      am4core.color("#FFA76D"),
      am4core.color("#FFC49E"),
      am4core.color("#FFE2CE"),
      am4core.color("#003E60"),
      am4core.color("#005380"),
      am4core.color("#337559"),
      am4core.color("#6698B3"),
      am4core.color("#99ABCC"),
      am4core.color("#CCDDE6"),
    ];
  }

  if (target instanceof am4core.Line) {
    target.stroke = am4core.color("#000")
    target.strokeOpacity = 0.5
  }

  if (target instanceof am4core.Label) {
    target.fill = am4core.color("#000")
  }

  if (target instanceof am4charts.Axis) {
    target.fill = am4core.color("#000")
    target.stroke = am4core.color("#000")
    target.strokeOpacity = 0.4
  }

  if (target instanceof am4core.InterfaceColorSet) {
    target.setFor("text", am4core.color("#000"));
    target.setFor("stroke", am4core.color("#000"))
    // target.setFor("fill", am4core.color("#000"))
    target.setFor("grid", am4core.color("#000"))
    target.setFor("alternativeText", am4core.color("#FFF"))
    target.setFor("primaryButton", am4core.color("#FF6C0C"));
    target.setFor("primaryButtonHover", am4core.color("#FF6C0C").lighten(-0.2));
    target.setFor("secondaryButton", am4core.color("#FF6C0C"));
    target.setFor(
      "secondaryButtonHover",
      am4core.color("#FF6C0C").lighten(-0.2)
    );
    target.setFor(
      "secondaryButtonDown",
      am4core.color("#FF6C0C").lighten(-0.2)
    );
    target.setFor(
      "secondaryButtonActive",
      am4core.color("#FF6C0C").lighten(-0.2)
    );
    target.setFor("secondaryButtonText", am4core.color("#000"));
    target.setFor(
      "secondaryButtonStroke",
      am4core.color("#FF6C0C").lighten(-0.2)
    );
  }
}

export function am4themes_ixThemeDark(target) {
  if (target instanceof am4core.ColorSet) {
    target.list = [
      am4core.color("#FF6C0C"),
      am4core.color("#BF5109"),
      am4core.color("#FF893D"),
      am4core.color("#FFA76D"),
      am4core.color("#FFC49E"),
      am4core.color("#FFE2CE"),
      am4core.color("#003E60"),
      am4core.color("#005380"),
      am4core.color("#337559"),
      am4core.color("#6698B3"),
      am4core.color("#99ABCC"),
      am4core.color("#CCDDE6"),
    ];
  }

  if (target instanceof am4core.Line) {
    target.stroke = am4core.color("#FFF")
    target.strokeOpacity = 0.5
  }

  if (target instanceof am4core.Label) {
    target.fill = am4core.color("#FFF")
  }
  if (target instanceof am4core.Tooltip) {
    target.fill = am4core.color("#FFF")
  }

  if (target instanceof am4charts.Axis) {
    target.fill = am4core.color("#FFF")
    target.stroke = am4core.color("#FFF")
    target.strokeOpacity = 0.4
  }

  if (target instanceof am4core.InterfaceColorSet) {
    target.setFor("text", am4core.color("#FFFFFF"));
    target.setFor("stroke", am4core.color("#FFF"))
    // target.setFor("fill", am4core.color("#FFF"))
    target.setFor("grid", am4core.color("#FFF"))
    target.setFor("alternativeText", am4core.color("#FFF"))
    target.setFor("primaryButton", am4core.color("#FF6C0C"));
    target.setFor("primaryButtonHover", am4core.color("#FF6C0C").lighten(-0.2));
    target.setFor("secondaryButton", am4core.color("#FF6C0C"));
    target.setFor(
      "secondaryButtonHover",
      am4core.color("#FF6C0C").lighten(-0.2)
    );
    target.setFor(
      "secondaryButtonDown",
      am4core.color("#FF6C0C").lighten(-0.2)
    );
    target.setFor(
      "secondaryButtonActive",
      am4core.color("#FF6C0C").lighten(-0.2)
    );
    target.setFor("secondaryButtonText", am4core.color("#FFFFFF"));
    target.setFor(
      "secondaryButtonStroke",
      am4core.color("#FF6C0C").lighten(-0.2)
    );
  }
}
