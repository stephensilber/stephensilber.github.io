const colors = require('tailwindcss/colors')

module.exports = {
  // purge: ['./pages/**/*.js', './components/**/*.js'],
  darkMode: 'class', // or 'media' or 'class'
  theme: {
    extend: {
      shadow: ['active'],
      boxSizing: ['hover', 'focus', 'active'],
      colors: {
        gray: colors.coolGray, // coolGray, blueGray, gray, trueGray, warmGray
        orange: {
          DEFAULT: "#FF6C0C"
        }
      }
    },
  },
  variants: {
    extend: {},
  },
  plugins: [
    require('@tailwindcss/forms')
  ],
}
