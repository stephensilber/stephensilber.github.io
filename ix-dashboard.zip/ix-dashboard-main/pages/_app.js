import "../styles/globals.css";
import Layout from "../components/Layout";
import withDarkMode from 'next-dark-mode'

function MyApp({ Component, pageProps }) {
  return (
    <Layout>
      <Component {...pageProps} />
    </Layout>
  );
}

export default withDarkMode(MyApp);
