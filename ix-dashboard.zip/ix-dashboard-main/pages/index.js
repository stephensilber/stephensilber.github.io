import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Head from "next/head";
import Widget from "../components/Widget";
import Table from "../components/Table";
import StatWidget from "../components/StatWidget";
import tableData from "../data/tableData.json";

const rows = tableData;

const stats = [
  { title: "Bounce Rate", value: "9%", previousValue: "7%", delta: 23},
  { title: "Visits", value: "57.6 K", previousValue: "42.5 K", delta: 26},
  { title: "New Visits", value: "18.2 K", previousValue: "15.5 K", delta: 14},
]

export default function Home() {
  const [selectedStatIndex, setSelectedStatIndex] = useState(null);
  return (
    <div>
      <Head>
        <title>Dashboard</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <main className="main w-full">
        <div className="min-h-screen w-full py-4">
          <StatsWidgetSection title="Last 30 Days">
            {stats.map((stat, index) => {
              return (<StatWidget
              key={index}
              title={stat.title}
              value={stat.value}
              previousValue={stat.previousValue}
              selected={selectedStatIndex === index}
              onClick={() =>
                setSelectedStatIndex(selectedStatIndex === index ? null : index)
              }
            />)
            })}
          </StatsWidgetSection>
          <AnimatePresence initial={false}>
            {selectedStatIndex !== null && (
              <motion.div
                key={"stateDetails"}
                initial={{ opacity: 0, height: 0, transition: 0.2 }}
                animate={{ opacity: 1, height: "auto", transition: 0.2 }}
                exit={{ opacity: 0, height: 0, transition: 0.2 }}
              >
                <WidgetSection>
                  <Widget
                    identifier="divergentLine2"
                    title={stats[selectedStatIndex].title}
                    widgetSize={"full"}
                    chartType="line"
                    datasourceUrl="../data/stock.json"
                  />
                </WidgetSection>
              </motion.div>
            )}
          </AnimatePresence>
          <WidgetSection title="Overview">
            <Widget
              identifier="divergentLine"
              title={"Projected Performance"}
              widgetSize={"full"}
              chartType="divergentLine"
              datasourceUrl="../data/stock.json"
            />
          </WidgetSection>
          <WidgetSection>
            <Widget
              identifier="bubble"
              widgetSize={"2/3"}
              title={"Income vs. Life Expectancy"}
              chartType="bubble"
              dataSourceUrl="../data/radar.json"
            />
            <Widget
              identifier="line"
              widgetSize={"1/3"}
              chartType="line"
              dataSourceUrl="../data/line.json"
            />
          </WidgetSection>
          <WidgetSection>
            <Widget
              identifier="drilldownPie1"
              title={"Form Reports"}
              widgetSize={"1/2"}
              chartType="drilldownPie"
              dataSourceUrl="../data/line.json"
            />
            <Widget
              identifier="column"
              widgetSize={"1/2"}
              chartType="column"
              dataSourceUrl="../data/line.json"
            />
          </WidgetSection>
          <WidgetSection>
            <Widget
              identifier="clusteredColumn"
              widgetSize={"2/3"}
              chartType="clusteredColumn"
              dataSourceUrl="../data/line.json"
            />
            <Widget
              identifier="line3"
              widgetSize={"1/3"}
              chartType="line"
              dataSourceUrl="../data/line.json"
            />
          </WidgetSection>
          <WidgetSection>
            <Widget
              identifier="stock"
              title={"Historical Stock Chart"}
              widgetSize={"full"}
              chartType="stock"
              datasourceUrl="../data/stock.json"
            />
          </WidgetSection>
          <div className="w-full min-h-full">
            <h3 class="text-lg leading-6 font-bold text-gray-900 dark:text-gray-100 mb-4 mt-4">
              Customers
            </h3>
            <Table titles={["Name", "Title", "Email", "Role"]} rows={rows} />
          </div>
        </div>
      </main>

      <footer></footer>
    </div>
  );
}

export function StatsWidgetSection(props) {
  return (
    <div>
      <h3 class="text-lg leading-6 font-bold text-gray-900 dark:text-gray-100">
        {props.title}
      </h3>
      <dl class="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-3  mb-2 lg:mb-4">
        {props.children}
      </dl>
    </div>
  );
}

export function WidgetSection(props) {
  return (
    <div className="flex flex-col">
      {props.title && (
        <h3 class="text-lg leading-6 font-bold text-gray-900 dark:text-gray-100 mb-4 mt-4">
          {props.title}
        </h3>
      )}
      <div className="flex flex-col lg:flex-row w-full min-h-full lg:space-x-2 space-y-2 lg:space-y-0 mb-2 lg:mb-4">
        {props.children}
      </div>
    </div>
  );
}

Home.getInitialProps = async (context) => {
  return {
    title: "Dashboard",
  };
};
