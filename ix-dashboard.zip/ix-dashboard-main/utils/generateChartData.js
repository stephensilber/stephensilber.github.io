export function generateChartData() {
  var data = [];
  var price1 = 1000;
  var price2 = 2000;
  var price3 = 3000;
  var quantity = 1000;
  for (var i = 15; i < 3000; i++) {
    price1 += Math.round((Math.random() < 0.5 ? 1 : -1) * Math.random() * 100);
    price2 += Math.round((Math.random() < 0.5 ? 1 : -1) * Math.random() * 100);
    price3 += Math.round((Math.random() < 0.5 ? 1 : -1) * Math.random() * 100);

    if (price1 < 100) {
      price1 = 100;
    }

    if (price2 < 100) {
      price2 = 100;
    }

    if (price3 < 100) {
      price3 = 100;
    }

    quantity += Math.round(
      (Math.random() < 0.5 ? 1 : -1) * Math.random() * 500
    );

    if (quantity < 0) {
      quantity *= -1;
    }
    data.push({
      date: new Date(2012, 0, i),
      price1: price1,
      price2: price2,
      price3: price3,
      quantity: quantity,
    });
  }

  return data;
}
