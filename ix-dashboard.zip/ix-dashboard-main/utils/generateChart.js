import { am4themes_ixThemeLight } from "../styles/chartTheme";

let am4core = null;
let am4charts = null;
let am4themesAnimated = null;

if (process.browser) {
  am4core = require("@amcharts/amcharts4/core");
  am4charts = require("@amcharts/amcharts4/charts");
  am4themesAnimated = require("@amcharts/amcharts4/themes/animated");
  am4core.useTheme(am4themesAnimated.default);
  am4core.useTheme(am4themes_ixThemeLight);
}

export function generateDivergentLineChart(identifier, data) {
  var chart = am4core.create(identifier, am4charts.XYChart);
  chart.responsive.enabled = true;

  chart.responsive.rules.push({
    relevant: function (target) {
      if (target.pixelWidth <= 400) {
        return true;
      }

      return false;
    },
    state: function (target, stateId) {
      if (target instanceof am4charts.Chart) {
        var state = target.states.create(stateId);
        state.properties.paddingTop = 0;
        state.properties.paddingRight = 0;
        state.properties.paddingBottom = 5;
        state.properties.paddingLeft = 0;
        return state;
      }

      if (target instanceof am4core.Scrollbar) {
        var state = target.states.create(stateId);
        state.properties.marginBottom = -10;
        return state;
      }

      if (target instanceof am4charts.Legend) {
        var state = target.states.create(stateId);
        state.properties.paddingTop = 10;
        state.properties.maxRows = 2;
        state.properties.maxWidth = "100%";
        state.properties.paddingRight = 0;
        state.properties.scale = 0.8;
        state.properties.paddingBottom = 0;
        state.properties.paddingLeft = 0;
        state.properties.marginLeft = 0;
        state.properties.marginBottom = 24;
        return state;
      }

      if (target instanceof am4charts.AxisRendererY) {
        var state = target.states.create(stateId);
        state.properties.inside = true;
        state.properties.maxLabelPosition = 0.99;
        return state;
      }

      if (
        target instanceof am4charts.AxisLabel &&
        target.parent instanceof am4charts.AxisRendererY
      ) {
        var state = target.states.create(stateId);
        state.properties.dy = -15;
        state.properties.dx = 5;
        state.properties.scale = 0.75;
        state.properties.paddingTop = 3;
        state.properties.paddingRight = 5;
        state.properties.paddingBottom = 3;
        state.properties.paddingLeft = 5;

        return state;
      }

      if (
        target instanceof am4charts.AxisLabel &&
        target.parent instanceof am4charts.AxisRendererX
      ) {
        var state = target.states.create(stateId);
        state.properties.scale = 0.75;
        state.properties.paddingTop = 3;
        state.properties.paddingRight = 5;
        state.properties.paddingBottom = 3;
        state.properties.paddingLeft = 5;

        return state;
      }

      // if ((target instanceof am4core.Rectangle) && (target.parent instanceof am4charts.AxisLabel) && (target.parent.parent instanceof am4charts.AxisRendererY)) {
      //   var state = target.states.create(stateId);
      //   state.properties.fill = am4core.color("#f00");
      //   state.properties.fillOpacity = 0.5;
      //   return state;
      // }

      return null;
    },
  });

  chart.dateFormatter.dateFormat = "MMM YYYY";
  chart.numberFormatter.numberFormat = "#.#a";
  chart.numberFormatter.bigNumberPrefixes = [
    { number: 1e3, suffix: "K" },
    { number: 1e6, suffix: "M" },
    { number: 1e9, suffix: "B" },
  ];

  // Chart title
  var title = chart.titles.create();
  // title.text = "Projected infection dynamics";
  // title.fontSize = 20;
  title.paddingBottom = 10;

  // Add data
  chart.data = [
    {
      date: new Date(2020, 0, 1),
      observed: 0,
    },
    {
      date: new Date(2020, 1, 1),
      observed: 4000,
    },
    {
      date: new Date(2020, 2, 1),
      observed: 55000,
    },
    {
      date: new Date(2020, 3, 1),
      observed: 220000,
    },
    {
      date: new Date(2020, 4, 1),
      observed: 390000,
    },
    {
      date: new Date(2020, 5, 1),
      observed: 550000,
    },
    {
      date: new Date(2020, 6, 1),
      observed: 720000,
      easing: 720000,
      projection: 720000,
      stricter: 720000,
    },
    {
      date: new Date(2020, 7, 1),
      easing: 900000,
      projection: 900000,
      stricter: 900000,
    },
    {
      date: new Date(2020, 8, 1),
      easing: 1053000,
      projection: 1053000,
      stricter: 1053000,
    },
    {
      date: new Date(2020, 9, 1),
      easing: 1252000,
      projection: 1249000,
      stricter: 1232000,
    },
    {
      date: new Date(2020, 10, 1),
      easing: 1674000,
      projection: 1604000,
      stricter: 1415000,
    },
    {
      date: new Date(2020, 11, 1),
      easing: 3212000,
      projection: 2342000,
      stricter: 1751000,
    },
  ];

  // Create axes
  var dateAxis = chart.xAxes.push(new am4charts.DateAxis());
  dateAxis.renderer.grid.template.location = 0;
  // dateAxis.renderer.labels.template.fill = am4core.color("#FFF") // DARKMODE
  dateAxis.renderer.minGridDistance = 30;

  var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
  valueAxis.renderer.inside = true;
  valueAxis.renderer.labels.template.verticalCenter = "bottom";
  // valueAxis.renderer.labels.template.fill = am4core.color("#FFF") // DARKMODE
  valueAxis.renderer.labels.template.dx = -5;
  valueAxis.renderer.labels.template.dy = 10;
  valueAxis.renderer.maxLabelPosition = 0.95;
  valueAxis.title.text = "";
  valueAxis.title.marginRight = 5;

  // Create series
  function createSeries(field, name, color, dashed) {
    var series = chart.series.push(new am4charts.LineSeries());
    series.dataFields.valueY = field;
    series.dataFields.dateX = "date";
    series.name = name;

    series.tooltip.getFillFromObject = false;
    series.tooltip.label.fill = am4core.color("#000");
    series.tooltipText = "[bold]{name}[/]\n{dateX}: [b]{valueY}[/]";
    series.strokeWidth = 2;
    series.smoothing = "monotoneX";
    series.stroke = color;

    if (dashed) {
      series.strokeDasharray = "5 3";
    }

    return series;
  }

  createSeries("observed", "Observed", am4core.color("#FF6C0C"));
  createSeries("easing", "Easing rules", am4core.color("#FF893D"), true);
  createSeries("stricter", "Stricter rules", am4core.color("#BF5109"), true);
  createSeries("projection", "Projection", am4core.color("#FF6C0C"), true);

  const legend = new am4charts.Legend();
  legend.position = "bottom";

  chart.legend = legend;
  chart.cursor = new am4charts.XYCursor();

  return chart;
}

export function generateExplodingPieChart(identifier, data) {
  var container = am4core.create(identifier, am4core.Container);
  container.width = am4core.percent(100);
  container.height = am4core.percent(100);
  container.layout = "horizontal";

  var chart = container.createChild(am4charts.PieChart);

  // Add data
  chart.data = [
    {
      country: "Lithuania",
      litres: 500,
      subData: [
        { name: "A", value: 200 },
        { name: "B", value: 150 },
        { name: "C", value: 100 },
        { name: "D", value: 50 },
      ],
    },
    {
      country: "Czech Republic",
      litres: 300,
      subData: [
        { name: "A", value: 150 },
        { name: "B", value: 100 },
        { name: "C", value: 50 },
      ],
    },
    {
      country: "Ireland",
      litres: 200,
      subData: [
        { name: "A", value: 110 },
        { name: "B", value: 60 },
        { name: "C", value: 30 },
      ],
    },
    {
      country: "Germany",
      litres: 150,
      subData: [
        { name: "A", value: 80 },
        { name: "B", value: 40 },
        { name: "C", value: 30 },
      ],
    },
    {
      country: "Australia",
      litres: 140,
      subData: [
        { name: "A", value: 90 },
        { name: "B", value: 40 },
        { name: "C", value: 10 },
      ],
    },
    {
      country: "Austria",
      litres: 120,
      subData: [
        { name: "A", value: 60 },
        { name: "B", value: 30 },
        { name: "C", value: 30 },
      ],
    },
  ];

  // Add and configure Series
  var pieSeries = chart.series.push(new am4charts.PieSeries());
  pieSeries.dataFields.value = "litres";
  pieSeries.dataFields.category = "country";
  // pieSeries.labels.template.fill = am4core.color("#FFF")
  pieSeries.slices.template.states.getKey("active").properties.shiftRadius = 0;
  //pieSeries.labels.template.text = "{category}\n{value.percent.formatNumber('#.#')}%";

  pieSeries.slices.template.events.on("hit", function (event) {
    selectSlice(event.target.dataItem);
  });

  var chart2 = container.createChild(am4charts.PieChart);
  chart2.width = am4core.percent(30);
  chart2.radius = am4core.percent(80);

  // Add and configure Series
  var pieSeries2 = chart2.series.push(new am4charts.PieSeries());
  pieSeries2.dataFields.value = "value";
  pieSeries2.dataFields.category = "name";
  pieSeries2.slices.template.states.getKey("active").properties.shiftRadius = 0;
  //pieSeries2.labels.template.radius = am4core.percent(50);
  //pieSeries2.labels.template.inside = true;
  //pieSeries2.labels.template.fill = am4core.color("#ffffff");
  pieSeries2.labels.template.disabled = true;
  pieSeries2.ticks.template.disabled = true;
  pieSeries2.alignLabels = false;
  pieSeries2.events.on("positionchanged", updateLines);

  var interfaceColors = new am4core.InterfaceColorSet();

  var line1 = container.createChild(am4core.Line);
  line1.strokeDasharray = "2,2";
  // line1.strokeOpacity = 0.5;
  // line1.stroke = am4core.color("#FFF")//interfaceColors.getFor("alternativeBackground"); // DARKMODE
  line1.isMeasured = false;

  var line2 = container.createChild(am4core.Line);
  line2.strokeDasharray = "2,2";
  // line2.strokeOpacity = 0.5;
  // line2.stroke = am4core.color("#FFF")//interfaceColors.getFor("alternativeBackground"); // DARKMODE
  line2.isMeasured = false;

  var selectedSlice;

  function selectSlice(dataItem) {
    selectedSlice = dataItem.slice;

    var fill = selectedSlice.fill;

    var count = dataItem.dataContext.subData.length;
    pieSeries2.colors.list = [];
    for (var i = 0; i < count; i++) {
      pieSeries2.colors.list.push(fill.brighten((i * 2) / count));
    }

    chart2.data = dataItem.dataContext.subData;
    pieSeries2.appear();

    var middleAngle = selectedSlice.middleAngle;
    var firstAngle = pieSeries.slices.getIndex(0).startAngle;
    var animation = pieSeries.animate(
      [
        { property: "startAngle", to: firstAngle - middleAngle },
        { property: "endAngle", to: firstAngle - middleAngle + 360 },
      ],
      600,
      am4core.ease.sinOut
    );
    animation.events.on("animationprogress", updateLines);

    selectedSlice.events.on("transformed", updateLines);

    //  var animation = chart2.animate({property:"dx", from:-container.pixelWidth / 2, to:0}, 2000, am4core.ease.elasticOut)
    //  animation.events.on("animationprogress", updateLines)
  }

  function updateLines() {
    if (selectedSlice) {
      var p11 = {
        x: selectedSlice.radius * am4core.math.cos(selectedSlice.startAngle),
        y: selectedSlice.radius * am4core.math.sin(selectedSlice.startAngle),
      };
      var p12 = {
        x:
          selectedSlice.radius *
          am4core.math.cos(selectedSlice.startAngle + selectedSlice.arc),
        y:
          selectedSlice.radius *
          am4core.math.sin(selectedSlice.startAngle + selectedSlice.arc),
      };

      p11 = am4core.utils.spritePointToSvg(p11, selectedSlice);
      p12 = am4core.utils.spritePointToSvg(p12, selectedSlice);

      var p21 = { x: 0, y: -pieSeries2.pixelRadius };
      var p22 = { x: 0, y: pieSeries2.pixelRadius };

      p21 = am4core.utils.spritePointToSvg(p21, pieSeries2);
      p22 = am4core.utils.spritePointToSvg(p22, pieSeries2);

      line1.x1 = p11.x;
      line1.x2 = p21.x;
      line1.y1 = p11.y;
      line1.y2 = p21.y;

      line2.x1 = p12.x;
      line2.x2 = p22.x;
      line2.y1 = p12.y;
      line2.y2 = p22.y;
    }
  }

  chart.events.on("datavalidated", function () {
    setTimeout(function () {
      selectSlice(pieSeries.dataItems.getIndex(0));
    }, 1000);
  });

  return chart;
}

export function generateDrillDownPieChart(identifier, data) {
  var data = [
    {
      category: "Critical",
      value: 89,
      color: am4core.color("#FF6C0C"),
      breakdown: [
        {
          category: "Sales",
          value: 29,
        },
        {
          category: "Support",
          value: 40,
        },
        {
          category: "Bugs",
          value: 11,
        },
        {
          category: "Other",
          value: 9,
        },
      ],
    },
    {
      category: "Acceptable",
      value: 71,
      color: am4core.color("#FFA76D"),
      breakdown: [
        {
          category: "Sales",
          value: 22,
        },
        {
          category: "Support",
          value: 30,
        },
        {
          category: "Bugs",
          value: 11,
        },
        {
          category: "Other",
          value: 10,
        },
      ],
    },
    {
      category: "Good",
      value: 120,
      color: am4core.color("#FF893D"),
      breakdown: [
        {
          category: "Sales",
          value: 60,
        },
        {
          category: "Support",
          value: 35,
        },
        {
          category: "Bugs",
          value: 15,
        },
        {
          category: "Other",
          value: 10,
        },
      ],
    },
  ];

  /**
   * Chart container
   */

  // Create chart instance
  var chart = am4core.create(identifier, am4core.Container);
  chart.width = am4core.percent(100);
  chart.height = am4core.percent(100);
  chart.layout = "vertical";

  // Create chart instance
  var pieChart = chart.createChild(am4charts.PieChart);
  pieChart.data = data;
  pieChart.innerRadius = am4core.percent(60);
  pieChart.width = am4core.percent(100);
  pieChart.height = am4core.percent(50);
  pieChart.responsive.enabled = true;

  pieChart.responsive.rules.push({
    relevant: function (target) {
      if (target.pixelWidth <= 400) {
        return true;
      }

      return false;
    },
    state: function (target, stateId) {
      if (target instanceof am4charts.Chart) {
        var state = target.states.create(stateId);
        // state.properties.width = am4core.percent(100);
        // state.properties.height = am4core.percent(50);
        return state;
      }
      if (target instanceof am4core.Label) {
        var state = target.states.create(stateId);
        if (target == label1) {
          state.properties.fontSize = 24;
          state.properties.dy = -20;
          state.properties.d = 2;
        } else {
          state.properties.dy = 5;
        }
        return state;
      }

      return null;
    },
  });
  // Add and configure Series
  var pieSeries = pieChart.series.push(new am4charts.PieSeries());
  pieSeries.dataFields.value = "value";
  pieSeries.dataFields.category = "category";
  pieSeries.slices.template.propertyFields.fill = "color";
  pieSeries.slices.template.strokeWidth = 2;
  pieSeries.labels.template.disabled = true;

  // Set up labels
  var label1 = pieChart.seriesContainer.createChild(am4core.Label);
  label1.text = "";
  label1.horizontalCenter = "middle";
  label1.fontSize = 28;
  label1.fontWeight = 600;
  label1.dy = -20;

  var label2 = pieChart.seriesContainer.createChild(am4core.Label);
  label2.text = "";
  label2.horizontalCenter = "middle";
  label2.fontSize = 12;
  label2.dy = 15;

  // Auto-select first slice on load
  pieChart.events.on("ready", function (ev) {
    pieSeries.slices.getIndex(0).isActive = true;
  });

  // Set up toggling events
  pieSeries.slices.template.events.on("toggled", function (ev) {
    if (ev.target.isActive) {
      // Untoggle other slices
      ev.target.fill = am4core.color("#FF6C0C");
      pieSeries.slices.each(function (slice) {
        if (slice != ev.target) {
          slice.isActive = false;
          slice.fill = am4core.color("#d3d3d3");
          slice.strokeWidth = 2;
          slice.stroke = am4core.color("#fff");
        }
      });

      // Update column chart
      columnSeries.appeared = false;
      columnChart.data = ev.target.dataItem.dataContext.breakdown;
      columnSeries.fill = ev.target.fill;
      columnSeries.reinit();

      // Update labels
      label1.text = pieChart.numberFormatter.format(
        ev.target.dataItem.values.value.percent,
        "#.'%'"
      );

      label2.text = ev.target.dataItem.category;
    }
  });

  /**
   * Column chart
   */

  // Create chart instance
  var columnChart = chart.createChild(am4charts.XYChart);
  columnChart.responsive.enabled = true;
  columnChart.width = am4core.percent(100);
  columnChart.height = am4core.percent(45);
  columnChart.paddingBottom = 0;

  columnChart.responsive.rules.push({
    relevant: function (target) {
      if (target.pixelWidth <= 400) {
        return true;
      }

      return false;
    },
    state: function (target, stateId) {
      return null;
    },
  });

  // Create axes
  var categoryAxis = columnChart.xAxes.push(new am4charts.CategoryAxis());
  categoryAxis.dataFields.category = "category";
  categoryAxis.renderer.grid.template.location = 0;
  categoryAxis.renderer.minGridDistance = 60;
  categoryAxis.tooltip.disabled = true;

  // categoryAxis.renderer.inside = false;
  // categoryAxis.renderer.inversed = true;
  // categoryAxis.renderer.labels.template.fontSize = 12;

  var valueAxis = columnChart.yAxes.push(new am4charts.ValueAxis());

  // Create series
  var columnSeries = columnChart.series.push(new am4charts.ColumnSeries());
  columnSeries.dataFields.valueY = "value";
  columnSeries.dataFields.categoryX = "category";
  columnSeries.columns.template.strokeWidth = 0;
  columnSeries.columns.template.column.cornerRadiusTopLeft = 4;
  columnSeries.columns.template.column.cornerRadiusTopRight = 4;

  return chart;
}

export function generateClusteredColumnChart(identifier, data) {
  var chart = am4core.create(identifier, am4charts.XYChart);
  chart.colors.step = 2;

  chart.legend = new am4charts.Legend();
  chart.legend.position = "top";
  chart.legend.paddingBottom = 20;
  chart.legend.labels.template.maxWidth = 180;
  chart.responsive.enabled = true;

  chart.responsive.rules.push({
    relevant: function (target) {
      if (target.pixelWidth <= 400) {
        return true;
      }

      return false;
    },
    state: function (target, stateId) {
      if (target instanceof am4charts.Chart) {
        var state = target.states.create(stateId);
        return state;
      }

      return null;
    },
  });

  var xAxis = chart.xAxes.push(new am4charts.CategoryAxis());
  xAxis.dataFields.category = "category";
  xAxis.renderer.cellStartLocation = 0.1;
  xAxis.renderer.cellEndLocation = 0.9;
  xAxis.renderer.grid.template.location = 0;
  xAxis.renderer.labels.template.fontSize = 12;

  var yAxis = chart.yAxes.push(new am4charts.ValueAxis());
  yAxis.min = 0;

  function createSeries(value, name) {
    var series = chart.series.push(new am4charts.ColumnSeries());
    series.dataFields.valueY = value;
    series.fill = chart.colors.next();
    series.stroke = null;
    series.columns.template.column.cornerRadiusTopLeft = 4;
    series.columns.template.column.cornerRadiusTopRight = 4;
    series.dataFields.categoryX = "category";
    series.name = name;

    series.events.on("hidden", arrangeColumns);
    series.events.on("shown", arrangeColumns);

    // var bullet = series.bullets.push(new am4charts.LabelBullet());
    // bullet.interactionsEnabled = false;
    // bullet.dy = 30;
    // bullet.label.text = "{valueY}";
    // bullet.label.fill = am4core.color("#ffffff");

    return series;
  }

  chart.data = [
    {
      category: "ADR",
      order: 40,
      match: 55,
    },
    {
      category: "ETF",
      order: 30,
      match: 78,
    },
    {
      category: "LARGE CAP",
      order: 27,
      match: 40,
    },
    {
      category: "SMID CAP",
      order: 50,
      match: 33,
    },
    {
      category: "REIT/MLP",
      order: 50,
      match: 33,
    },
    {
      category: "OTHER",
      order: 50,
      match: 33,
    },
  ];

  createSeries("order", "ORDER QTY");
  createSeries("match", "MATCH QTY");

  function arrangeColumns() {
    var series = chart.series.getIndex(0);

    var w =
      1 -
      xAxis.renderer.cellStartLocation -
      (1 - xAxis.renderer.cellEndLocation);
    if (series.dataItems.length > 1) {
      var x0 = xAxis.getX(series.dataItems.getIndex(0), "categoryX");
      var x1 = xAxis.getX(series.dataItems.getIndex(1), "categoryX");
      var delta = ((x1 - x0) / chart.series.length) * w;
      if (am4core.isNumber(delta)) {
        var middle = chart.series.length / 2;

        var newIndex = 0;
        chart.series.each(function (series) {
          if (!series.isHidden && !series.isHiding) {
            series.dummyData = newIndex;
            newIndex++;
          } else {
            series.dummyData = chart.series.indexOf(series);
          }
        });
        var visibleCount = newIndex;
        var newMiddle = visibleCount / 2;

        chart.series.each(function (series) {
          var trueIndex = chart.series.indexOf(series);
          var newIndex = series.dummyData;

          var dx = (newIndex - trueIndex + middle - newMiddle) * delta;

          series.animate(
            { property: "dx", to: dx },
            series.interpolationDuration,
            series.interpolationEasing
          );
          series.bulletsContainer.animate(
            { property: "dx", to: dx },
            series.interpolationDuration,
            series.interpolationEasing
          );
        });
      }
    }
  }

  return chart;
}

export function generateCandleStockChart(identifier, data) {
  var chart = am4core.create(identifier, am4charts.XYChart);
  chart.padding(0, 15, 0, 15);

  // Load data
  chart.dataSource.url =
    "https://www.amcharts.com/wp-content/uploads/assets/stock/MSFT.csv";
  chart.dataSource.parser = new am4core.CSVParser();
  chart.dataSource.parser.options.useColumnNames = true;
  chart.dataSource.parser.options.reverse = true;

  // the following line makes value axes to be arranged vertically.
  chart.leftAxesContainer.layout = "vertical";

  // uncomment this line if you want to change order of axes
  //chart.bottomAxesContainer.reverseOrder = true;

  var dateAxis = chart.xAxes.push(new am4charts.DateAxis());
  dateAxis.renderer.grid.template.location = 0;
  dateAxis.renderer.ticks.template.length = 8;
  dateAxis.renderer.ticks.template.strokeOpacity = 0.1;
  dateAxis.renderer.grid.template.disabled = true;
  dateAxis.renderer.ticks.template.disabled = false;
  dateAxis.renderer.ticks.template.strokeOpacity = 0.2;
  dateAxis.renderer.minLabelPosition = 0.01;
  dateAxis.renderer.maxLabelPosition = 0.99;
  dateAxis.keepSelection = true;
  dateAxis.minHeight = 30;

  dateAxis.groupData = true;
  dateAxis.minZoomCount = 5;

  // these two lines makes the axis to be initially zoomed-in
  // dateAxis.start = 0.7;
  // dateAxis.keepSelection = true;

  var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
  valueAxis.tooltip.disabled = true;
  valueAxis.zIndex = 1;
  valueAxis.renderer.baseGrid.disabled = false;
  valueAxis.renderer.background = am4core.color("#FFF");
  // height of axis
  valueAxis.height = am4core.percent(65);

  valueAxis.renderer.gridContainer.background.fill = am4core.color("#000000");
  valueAxis.renderer.gridContainer.background.fillOpacity = 0.05;
  valueAxis.renderer.inside = true;
  valueAxis.renderer.labels.template.verticalCenter = "bottom";
  valueAxis.renderer.labels.template.padding(2, 2, 2, 2);

  //valueAxis.renderer.maxLabelPosition = 0.95;
  valueAxis.renderer.fontSize = "0.8em";

  var series = chart.series.push(new am4charts.CandlestickSeries());
  series.dataFields.dateX = "Date";
  series.dataFields.openValueY = "Open";
  series.dataFields.valueY = "Close";
  series.dataFields.lowValueY = "Low";
  series.dataFields.highValueY = "High";
  series.clustered = false;
  series.tooltipText =
    "open: {openValueY.value}\nlow: {lowValueY.value}\nhigh: {highValueY.value}\nclose: {valueY.value}";
  series.name = "MSFT";
  series.defaultState.transitionDuration = 0;

  var valueAxis2 = chart.yAxes.push(new am4charts.ValueAxis());
  valueAxis2.tooltip.disabled = true;
  // height of axis
  valueAxis2.height = am4core.percent(35);
  valueAxis2.zIndex = 3;
  // this makes gap between panels
  valueAxis2.marginTop = 30;
  valueAxis2.renderer.baseGrid.disabled = true;
  valueAxis2.renderer.inside = true;
  valueAxis2.renderer.labels.template.verticalCenter = "bottom";
  valueAxis2.renderer.labels.template.padding(2, 2, 2, 2);
  //valueAxis.renderer.maxLabelPosition = 0.95;
  valueAxis2.renderer.fontSize = "0.8em";

  valueAxis2.renderer.gridContainer.background.fill = am4core.color("#000000");
  valueAxis2.renderer.gridContainer.background.fillOpacity = 0.05;

  var series2 = chart.series.push(new am4charts.ColumnSeries());
  series2.dataFields.dateX = "Date";
  series2.clustered = false;
  series2.dataFields.valueY = "Volume";
  series2.yAxis = valueAxis2;
  series2.tooltipText = "{valueY.value}";
  series2.name = "Series 2";
  // volume should be summed
  series2.groupFields.valueY = "sum";
  series2.defaultState.transitionDuration = 0;

  chart.cursor = new am4charts.XYCursor();

  var scrollbarX = new am4charts.XYChartScrollbar();

  var sbSeries = chart.series.push(new am4charts.LineSeries());
  sbSeries.dataFields.valueY = "Close";
  sbSeries.dataFields.dateX = "Date";
  scrollbarX.series.push(sbSeries);
  sbSeries.disabled = true;
  scrollbarX.marginBottom = 20;
  chart.scrollbarX = scrollbarX;
  scrollbarX.scrollbarChart.xAxes.getIndex(0).minHeight = undefined;

  /**
   * Set up external controls
   */

  // Date format to be used in input fields
  var inputFieldFormat = "yyyy-MM-dd";

  document.getElementById("b1m").addEventListener("click", function () {
    var max = dateAxis.groupMax["day1"];
    var date = new Date(max);
    am4core.time.add(date, "month", -1);
    zoomToDates(date);
  });

  document.getElementById("b3m").addEventListener("click", function () {
    var max = dateAxis.groupMax["day1"];
    var date = new Date(max);
    am4core.time.add(date, "month", -3);
    zoomToDates(date);
  });

  document.getElementById("b6m").addEventListener("click", function () {
    var max = dateAxis.groupMax["day1"];
    var date = new Date(max);
    am4core.time.add(date, "month", -6);
    zoomToDates(date);
  });

  document.getElementById("b1y").addEventListener("click", function () {
    var max = dateAxis.groupMax["day1"];
    var date = new Date(max);
    am4core.time.add(date, "year", -1);
    zoomToDates(date);
  });

  document.getElementById("bytd").addEventListener("click", function () {
    var max = dateAxis.groupMax["day1"];
    var date = new Date(max);
    am4core.time.round(date, "year", 1);
    zoomToDates(date);
  });

  document.getElementById("bmax").addEventListener("click", function () {
    var min = dateAxis.groupMin["day1"];
    var date = new Date(min);
    zoomToDates(date);
  });

  dateAxis.events.on("selectionextremeschanged", function () {
    updateFields();
  });

  dateAxis.events.on("extremeschanged", updateFields);

  function updateFields() {
    var minZoomed =
      dateAxis.minZoomed +
      am4core.time.getDuration(
        dateAxis.mainBaseInterval.timeUnit,
        dateAxis.mainBaseInterval.count
      ) *
        0.5;
    document.getElementById("fromfield").value = chart.dateFormatter.format(
      minZoomed,
      inputFieldFormat
    );
    document.getElementById("tofield").value = chart.dateFormatter.format(
      new Date(dateAxis.maxZoomed),
      inputFieldFormat
    );
  }

  document.getElementById("fromfield").addEventListener("keyup", updateZoom);
  document.getElementById("tofield").addEventListener("keyup", updateZoom);

  var zoomTimeout;
  function updateZoom() {
    if (zoomTimeout) {
      clearTimeout(zoomTimeout);
    }
    zoomTimeout = setTimeout(function () {
      var start = document.getElementById("fromfield").value;
      var end = document.getElementById("tofield").value;
      if (
        start.length < inputFieldFormat.length ||
        end.length < inputFieldFormat.length
      ) {
        return;
      }
      var startDate = chart.dateFormatter.parse(start, inputFieldFormat);
      var endDate = chart.dateFormatter.parse(end, inputFieldFormat);

      if (startDate && endDate) {
        dateAxis.zoomToDates(startDate, endDate);
      }
    }, 500);
  }

  function zoomToDates(date) {
    var min = dateAxis.groupMin["day1"];
    var max = dateAxis.groupMax["day1"];
    dateAxis.keepSelection = true;
    //dateAxis.start = (date.getTime() - min)/(max - min);
    //dateAxis.end = 1;

    dateAxis.zoom({ start: (date.getTime() - min) / (max - min), end: 1 });
  }

  return chart;
}

export function generateStockChart(identifier, data) {
  let x = am4core.create(identifier, am4charts.XYChart);
  x.padding(0, 15, 0, 15);
  x.colors.step = 3;
  x.leftAxesContainer.layout = "vertical";
  x.data = data;

  var dateAxis = x.xAxes.push(new am4charts.DateAxis());
  dateAxis.renderer.grid.template.location = 0;
  dateAxis.renderer.ticks.template.length = 8;
  dateAxis.renderer.ticks.template.strokeOpacity = 0.1;
  dateAxis.renderer.grid.template.disabled = true;
  dateAxis.renderer.ticks.template.disabled = false;
  dateAxis.renderer.ticks.template.strokeOpacity = 0.2;
  dateAxis.renderer.minLabelPosition = 0.01;
  dateAxis.renderer.maxLabelPosition = 0.99;
  dateAxis.keepSelection = true;

  dateAxis.groupData = true;
  dateAxis.minZoomCount = 5;

  // these two lines makes the axis to be initially zoomed-in
  // dateAxis.start = 0.7;
  // dateAxis.keepSelection = true;

  var valueAxis = x.yAxes.push(new am4charts.ValueAxis());
  valueAxis.tooltip.disabled = true;
  valueAxis.zIndex = 1;
  valueAxis.renderer.baseGrid.disabled = true;
  // height of axis
  valueAxis.height = am4core.percent(65);

  valueAxis.renderer.gridContainer.background.fill = am4core.color("#000000");
  valueAxis.renderer.gridContainer.background.fillOpacity = 0.0;
  valueAxis.renderer.inside = true;
  valueAxis.renderer.labels.template.verticalCenter = "bottom";
  valueAxis.renderer.labels.template.padding(2, 2, 2, 2);

  //valueAxis.renderer.maxLabelPosition = 0.95;
  valueAxis.renderer.fontSize = "0.8em";

  var series1 = x.series.push(new am4charts.LineSeries());
  series1.strokeWidth = 2;
  series1.dataFields.dateX = "date";
  series1.dataFields.valueY = "price1";
  series1.dataFields.valueYShow = "changePercent";
  series1.tooltipText =
    "{name}: {valueY.changePercent.formatNumber('[#0c0]+#.00|[#c00]#.##|0')}%";
  series1.name = "Stock A";
  series1.tooltip.getFillFromObject = false;
  series1.tooltip.background.fill = am4core.color("#fff");
  series1.tooltip.background.strokeWidth = 2;
  series1.tooltip.label.fill = am4core.color("#000");

  // var series2 = x.series.push(new am4charts.LineSeries());
  // series2.strokeWidth = 2;
  // series2.dataFields.dateX = "date";
  // series2.dataFields.valueY = "price2";
  // series2.dataFields.valueYShow = "changePercent";
  // series2.tooltipText =
  //   "{name}: {valueY.changePercent.formatNumber('[#0c0]+#.00|[#c00]#.##|0')}%";
  // series2.name = "Stock B";
  // series2.tooltip.getFillFromObject = false;
  // series2.tooltip.background.fill = am4core.color("#fff");
  // series2.tooltip.background.strokeWidth = 2;
  // series2.tooltip.label.fill = am4core.color("#000");

  var series3 = x.series.push(new am4charts.LineSeries());
  series3.strokeWidth = 2;
  series3.stroke = am4core.color("#337599");
  series3.dataFields.dateX = "date";
  series3.dataFields.valueY = "price3";
  series3.dataFields.valueYShow = "changePercent";
  series3.tooltipText =
    "{name}: {valueY.changePercent.formatNumber('[#0c0]+#.00|[#c00]#.##|0')}%";
  series3.name = "Stock C";
  series3.tooltip.getFillFromObject = false;
  series3.tooltip.background.fill = am4core.color("#fff");
  series3.tooltip.background.strokeWidth = 2;
  series3.tooltip.label.fill = am4core.color("#000");

  var valueAxis2 = x.yAxes.push(new am4charts.ValueAxis());
  valueAxis2.tooltip.disabled = true;
  // height of axis
  valueAxis2.height = am4core.percent(35);
  valueAxis2.zIndex = 3;
  // this makes gap between panels
  valueAxis2.marginTop = 30;
  valueAxis2.renderer.baseGrid.disabled = true;
  valueAxis2.renderer.inside = true;
  valueAxis2.renderer.labels.template.verticalCenter = "bottom";
  valueAxis2.renderer.labels.template.padding(2, 2, 2, 2);
  //valueAxis.renderer.maxLabelPosition = 0.95;
  valueAxis2.renderer.fontSize = "0.8em";

  valueAxis2.renderer.gridContainer.background.fill = am4core.color("#000000");
  valueAxis2.renderer.gridContainer.background.fillOpacity = 0.05;

  var volumeSeries = x.series.push(new am4charts.ColumnSeries());
  volumeSeries.fillOpacity = 1;
  volumeSeries.fill = series1.stroke;
  volumeSeries.stroke = series1.stroke;
  volumeSeries.dataFields.dateX = "date";
  volumeSeries.dataFields.valueY = "quantity";
  volumeSeries.yAxis = valueAxis2;
  volumeSeries.tooltipText = "Volume: {valueY.value}";
  volumeSeries.name = "Series 2";
  volumeSeries.tooltip.background.fill = am4core.color("#fff");
  volumeSeries.tooltip.background.strokeWidth = 2;
  volumeSeries.tooltip.label.fill = am4core.color("#000");
  // volume should be summed
  volumeSeries.groupFields.valueY = "sum";

  x.cursor = new am4charts.XYCursor();

  // var scrollbarX = new am4charts.XYChartScrollbar();
  // scrollbarX.series.push(series1);
  // scrollbarX.marginBottom = 20;
  // var sbSeries = scrollbarX.scrollbarChart.series.getIndex(0);
  // sbSeries.dataFields.valueYShow = undefined;
  // x.scrollbarX = scrollbarX;

  // // Add range selector
  // var selector = new am4plugins_rangeSelector.DateAxisRangeSelector();
  // selector.container = document.getElementById("controls");
  // selector.axis = dateAxis;

  return x;
}

export function generatePieChart(identifier, data) {
  let x = am4core.create(identifier, am4charts.PieChart3D);
  x.hiddenState.properties.opacity = 0; // this creates initial fade-in
  x.data = data;
  x.innerRadius = am4core.percent(30);

  var pieSeries = x.series.push(new am4charts.PieSeries3D());
  pieSeries.dataFields.value = "litres";
  pieSeries.dataFields.category = "country";
  pieSeries.slices.template.stroke = am4core.color("#fff");
  pieSeries.slices.template.strokeWidth = 2;
  pieSeries.slices.template.strokeOpacity = 1;

  pieSeries.hiddenState.properties.opacity = 1;
  pieSeries.hiddenState.properties.endAngle = -90;
  pieSeries.hiddenState.properties.startAngle = -90;

  return x;
}

export function generateLineChart(identifier, data) {
  let x = am4core.create(identifier, am4charts.XYChart);
  x.data = data;

  let categoryAxis = x.xAxes.push(new am4charts.CategoryAxis());
  categoryAxis.dataFields.category = "country";
  categoryAxis.title.text = "Countries";
  categoryAxis.title.scale = 0.75;
  categoryAxis.renderer.labels.template.fontSize = 10;

  let valueAxis = x.yAxes.push(new am4charts.ValueAxis());
  valueAxis.title.text = "Litres sold (M)";
  valueAxis.title.scale = 0.75;
  valueAxis.renderer.labels.template.fontSize = 10;

  let series = x.series.push(new am4charts.LineSeries());
  series.strokeWidth = 3;
  series.name = "Sales";
  series.dataFields.valueY = "litres";
  series.dataFields.categoryX = "country";

  x.cursor = new am4charts.XYCursor();

  return x;
}

export function generateColumnChart(identifier, data) {
  let x = am4core.create(identifier, am4charts.XYChart);
  x.data = data;
  x.tooltip.getFillFromObject = false;
  x.tooltip.background.fill = am4core.color("#fff");

  let categoryAxis = x.xAxes.push(new am4charts.CategoryAxis());
  categoryAxis.dataFields.category = "country";
  categoryAxis.title.text = "Countries";
  categoryAxis.renderer.labels.template.fontSize = 10;

  let valueAxis = x.yAxes.push(new am4charts.ValueAxis());
  valueAxis.title.text = "Litres sold (M)";
  valueAxis.renderer.labels.template.fontSize = 10;

  let series = x.series.push(new am4charts.ColumnSeries());
  var segment = series.columns.template;
  segment.interactionsEnabled = true;

  var hoverState = segment.states.create("hover");
  hoverState.properties.fill = am4core.color("#FF6C0C");

  series.name = "Sales";
  series.columns.template.strokeWidth = 0;
  series.columns.template.fill = am4core.color("#d3d3d3");
  series.strokeWidth = 3;

  series.tooltip.background.fill = am4core.color("#fff");
  series.columns.template.tooltipText =
    "Series: {name}\nCategory: {categoryX}\nValue: {valueY}";
  series.dataFields.valueY = "litres";
  series.dataFields.categoryX = "country";

  x.cursor = new am4charts.XYCursor();

  return x;
}

export function generateBubbleChart(identifier, data) {
  var chart = am4core.create(identifier, am4charts.XYChart);
  chart.width = am4core.percent(96);
  chart.responsive.enabled = true;

  chart.responsive.rules.push({
    relevant: function (target) {
      if (target.pixelWidth <= 400) {
        return true;
      }

      return false;
    },
    state: function (target, stateId) {

      if (target instanceof am4charts.AxisRendererY) {
        var state = target.states.create(stateId);
        state.properties.inside = true;
        state.properties.maxLabelPosition = 0.99;
        return state;
      }

      if (
        target instanceof am4charts.AxisLabel &&
        target.parent instanceof am4charts.AxisRendererY
      ) {
        var state = target.states.create(stateId);
        state.properties.dy = -15;
        state.properties.dx = 5;
        state.properties.scale = 0.75;
        state.properties.paddingTop = 3;
        state.properties.paddingRight = 5;
        state.properties.paddingBottom = 3;
        state.properties.paddingLeft = 5;

        return state;
      }

      if (
        target instanceof am4charts.AxisLabel &&
        target.parent instanceof am4charts.AxisRendererX
      ) {
        var state = target.states.create(stateId);
        state.properties.scale = 0.8;
        state.properties.paddingTop = 3;
        state.properties.paddingRight = 35;
        state.properties.paddingBottom = 3;
        state.properties.paddingLeft = 5;
        state.properties.maxLabelPosition = 0.8;

        return state;
      }

      // if ((target instanceof am4core.Rectangle) && (target.parent instanceof am4charts.AxisLabel) && (target.parent.parent instanceof am4charts.AxisRendererY)) {
      //   var state = target.states.create(stateId);
      //   state.properties.fill = am4core.color("#f00");
      //   state.properties.fillOpacity = 0.5;
      //   return state;
      // }

      return null;
    },
  });
  var valueAxisX = chart.xAxes.push(new am4charts.ValueAxis());
  valueAxisX.renderer.ticks.template.disabled = true;
  valueAxisX.renderer.axisFills.template.disabled = true;

  var valueAxisY = chart.yAxes.push(new am4charts.ValueAxis());
  valueAxisY.renderer.ticks.template.disabled = true;
  valueAxisY.renderer.axisFills.template.disabled = true;

  var series = chart.series.push(new am4charts.LineSeries());
  series.dataFields.valueX = "x";
  series.dataFields.valueY = "y";
  series.dataFields.value = "value";
  series.strokeOpacity = 0;
  series.sequencedInterpolation = true;
  series.tooltip.pointerOrientation = "vertical";

  var bullet = series.bullets.push(new am4core.Circle());
  bullet.fill = am4core.color("#ff0000");
  bullet.propertyFields.fill = "color";
  bullet.strokeOpacity = 0;
  bullet.strokeWidth = 2;
  bullet.fillOpacity = 0.5;
  bullet.stroke = am4core.color("#ffffff");
  bullet.hiddenState.properties.opacity = 0;
  bullet.tooltipText =
    "[bold]{title}:[/]\nPopulation: {value.value}\nIncome: {valueX.value}\nLife expectancy:{valueY.value}";

  var outline = chart.plotContainer.createChild(am4core.Circle);
  outline.fillOpacity = 0;
  outline.strokeOpacity = 0.8;
  outline.stroke = am4core.color("#ff0000");
  outline.strokeWidth = 2;
  outline.hide(0);

  var blurFilter = new am4core.BlurFilter();
  outline.filters.push(blurFilter);

  bullet.events.on("over", function (event) {
    var target = event.target;
    outline.radius = target.pixelRadius + 2;
    outline.x = target.pixelX;
    outline.y = target.pixelY;
    outline.show();
  });

  bullet.events.on("out", function (event) {
    outline.hide();
  });

  var hoverState = bullet.states.create("hover");
  hoverState.properties.fillOpacity = 1;
  hoverState.properties.strokeOpacity = 1;

  series.heatRules.push({
    target: bullet,
    min: 2,
    max: 60,
    property: "radius",
  });

  bullet.adapter.add("tooltipY", function (tooltipY, target) {
    return -target.radius;
  });

  chart.cursor = new am4charts.XYCursor();
  chart.cursor.behavior = "zoomXY";
  chart.cursor.snapToSeries = series;

  // chart.scrollbarX = new am4core.Scrollbar();
  // chart.scrollbarY = new am4core.Scrollbar();

  chart.data = [
    {
      title: "Afghanistan",
      id: "AF",
      color: "#eea638",
      continent: "asia",
      x: 1349.69694102398,
      y: 60.524,
      value: 33397058,
    },
    {
      title: "Albania",
      id: "AL",
      color: "#d8854f",
      continent: "europe",
      x: 6969.30628256456,
      y: 77.185,
      value: 3227373,
    },
    {
      title: "Algeria",
      id: "DZ",
      color: "#de4c4f",
      continent: "africa",
      x: 6419.12782939372,
      y: 70.874,
      value: 36485828,
    },
    {
      title: "Angola",
      id: "AO",
      color: "#de4c4f",
      continent: "africa",
      x: 5838.15537582502,
      y: 51.498,
      value: 20162517,
    },
    {
      title: "Argentina",
      id: "AR",
      color: "#86a965",
      continent: "south_america",
      x: 15714.1031814398,
      y: 76.128,
      value: 41118986,
    },
    {
      title: "Armenia",
      id: "AM",
      color: "#d8854f",
      continent: "europe",
      x: 5059.0879636443,
      y: 74.469,
      value: 3108972,
    },
    {
      title: "Australia",
      id: "AU",
      color: "#8aabb0",
      continent: "australia",
      x: 36064.7372768548,
      y: 82.364,
      value: 22918688,
    },
    {
      title: "Austria",
      id: "AT",
      color: "#d8854f",
      continent: "europe",
      x: 36731.6287741081,
      y: 80.965,
      value: 8428915,
    },
    {
      title: "Azerbaijan",
      id: "AZ",
      color: "#d8854f",
      continent: "europe",
      x: 9291.02626998762,
      y: 70.686,
      value: 9421233,
    },
    {
      title: "Bahrain",
      id: "BH",
      color: "#eea638",
      continent: "asia",
      x: 24472.896235865,
      y: 76.474,
      value: 1359485,
    },
    {
      title: "Bangladesh",
      id: "BD",
      color: "#eea638",
      continent: "asia",
      x: 1792.55023464123,
      y: 70.258,
      value: 152408774,
    },
    {
      title: "Belarus",
      id: "BY",
      color: "#d8854f",
      continent: "europe",
      x: 13515.1610255056,
      y: 69.829,
      value: 9527498,
    },
    {
      title: "Belgium",
      id: "BE",
      color: "#d8854f",
      continent: "europe",
      x: 32585.0119650436,
      y: 80.373,
      value: 10787788,
    },
    {
      title: "Benin",
      id: "BJ",
      color: "#de4c4f",
      continent: "africa",
      x: 1464.13825459126,
      y: 59.165,
      value: 9351838,
    },
    {
      title: "Bhutan",
      id: "BT",
      color: "#eea638",
      continent: "asia",
      x: 6130.86235464324,
      y: 67.888,
      value: 750443,
    },
    {
      title: "Bolivia",
      id: "BO",
      color: "#86a965",
      continent: "south_america",
      x: 4363.43264453337,
      y: 66.969,
      value: 10248042,
    },
    {
      title: "Bosnia and Herzegovina",
      id: "BA",
      color: "#d8854f",
      continent: "europe",
      x: 7664.15281166303,
      y: 76.211,
      value: 3744235,
    },
    {
      title: "Botswana",
      id: "BW",
      color: "#de4c4f",
      continent: "africa",
      x: 14045.9403255843,
      y: 47.152,
      value: 2053237,
    },
    {
      title: "Brazil",
      id: "BR",
      color: "#86a965",
      continent: "south_america",
      x: 10383.5405937283,
      y: 73.667,
      value: 198360943,
    },
    {
      title: "Brunei",
      id: "BN",
      color: "#eea638",
      continent: "asia",
      x: 45658.2532642054,
      y: 78.35,
      value: 412892,
    },
    {
      title: "Bulgaria",
      id: "BG",
      color: "#d8854f",
      continent: "europe",
      x: 11669.7223127119,
      y: 73.448,
      value: 7397873,
    },
    {
      title: "Burkina Faso",
      id: "BF",
      color: "#de4c4f",
      continent: "africa",
      x: 1363.77981282077,
      y: 55.932,
      value: 17481984,
    },
    {
      title: "Burundi",
      id: "BI",
      color: "#de4c4f",
      continent: "africa",
      x: 484.090924612833,
      y: 53.637,
      value: 8749387,
    },
    {
      title: "Cambodia",
      id: "KH",
      color: "#eea638",
      continent: "asia",
      x: 2076.68958647462,
      y: 71.577,
      value: 14478320,
    },
    {
      title: "Cameroon",
      id: "CM",
      color: "#de4c4f",
      continent: "africa",
      x: 2094.09541317011,
      y: 54.61,
      value: 20468943,
    },
    {
      title: "Canada",
      id: "CA",
      color: "#a7a737",
      continent: "north_america",
      x: 35992.8327204722,
      y: 81.323,
      value: 34674708,
    },
    {
      title: "Cape Verde",
      id: "CV",
      color: "#de4c4f",
      continent: "africa",
      x: 3896.04113919638,
      y: 74.771,
      value: 505335,
    },
    {
      title: "Central African Rep.",
      id: "CF",
      color: "#de4c4f",
      continent: "africa",
      x: 718.264633200085,
      y: 49.517,
      value: 4575586,
    },
    {
      title: "Chad",
      id: "TD",
      color: "#de4c4f",
      continent: "africa",
      x: 1768.88201756553,
      y: 50.724,
      value: 11830573,
    },
    {
      title: "Chile",
      id: "CL",
      color: "#86a965",
      continent: "south_america",
      x: 15403.7608144625,
      y: 79.691,
      value: 17423214,
    },
    {
      title: "China",
      id: "CN",
      color: "#eea638",
      continent: "asia",
      x: 9501.57424554247,
      y: 75.178,
      value: 1353600687,
    },
    {
      title: "Colombia",
      id: "CO",
      color: "#86a965",
      continent: "south_america",
      x: 8035.65638212719,
      y: 73.835,
      value: 47550708,
    },
    {
      title: "Comoros",
      id: "KM",
      color: "#de4c4f",
      continent: "africa",
      x: 1027.40854349726,
      y: 60.661,
      value: 773344,
    },
    {
      title: "Congo, Dem. Rep.",
      id: "CD",
      color: "#de4c4f",
      continent: "africa",
      x: 403.164594003407,
      y: 49.643,
      value: 69575394,
    },
    {
      title: "Congo, Rep.",
      id: "CG",
      color: "#de4c4f",
      continent: "africa",
      x: 4106.51173855966,
      y: 58.32,
      value: 4233063,
    },
    {
      title: "Costa Rica",
      id: "CR",
      color: "#a7a737",
      continent: "north_america",
      x: 10827.6787293035,
      y: 79.712,
      value: 4793725,
    },
    {
      title: "Cote d'Ivoire",
      id: "CI",
      color: "#de4c4f",
      continent: "africa",
      x: 1491.51631215108,
      y: 50.367,
      value: 20594615,
    },
    {
      title: "Croatia",
      id: "HR",
      color: "#d8854f",
      continent: "europe",
      x: 13388.9902780816,
      y: 76.881,
      value: 4387376,
    },
    {
      title: "Cuba",
      id: "CU",
      color: "#a7a737",
      continent: "north_america",
      x: 10197.4191892126,
      y: 79.088,
      value: 11249266,
    },
    {
      title: "Cyprus",
      id: "CY",
      color: "#d8854f",
      continent: "europe",
      x: 23092.089792339,
      y: 79.674,
      value: 1129166,
    },
    {
      title: "Czech Rep.",
      id: "CZ",
      color: "#d8854f",
      continent: "europe",
      x: 22565.2975367042,
      y: 77.552,
      value: 10565678,
    },
    {
      title: "Denmark",
      id: "DK",
      color: "#d8854f",
      continent: "europe",
      x: 32731.2903910132,
      y: 79.251,
      value: 5592738,
    },
    {
      title: "Djibouti",
      id: "DJ",
      color: "#de4c4f",
      continent: "africa",
      x: 2244.60241376688,
      y: 61.319,
      value: 922708,
    },
    {
      title: "Dominican Rep.",
      id: "DO",
      color: "#a7a737",
      continent: "north_america",
      x: 6978.89657264408,
      y: 73.181,
      value: 10183339,
    },
    {
      title: "Ecuador",
      id: "EC",
      color: "#86a965",
      continent: "south_america",
      x: 7903.09487034651,
      y: 76.195,
      value: 14864987,
    },
    {
      title: "Egypt",
      id: "EG",
      color: "#de4c4f",
      continent: "africa",
      x: 6013.821462967,
      y: 70.933,
      value: 83958369,
    },
    {
      title: "El Salvador",
      id: "SV",
      color: "#a7a737",
      continent: "north_america",
      x: 5833.63022804714,
      y: 72.361,
      value: 6264129,
    },
    {
      title: "Equatorial Guinea",
      id: "GQ",
      color: "#de4c4f",
      continent: "africa",
      x: 13499.2115504397,
      y: 52.562,
      value: 740471,
    },
    {
      title: "Eritrea",
      id: "ER",
      color: "#de4c4f",
      continent: "africa",
      x: 613.716963797415,
      y: 62.329,
      value: 5580862,
    },
    {
      title: "Estonia",
      id: "EE",
      color: "#d8854f",
      continent: "europe",
      x: 18858.0538247661,
      y: 74.335,
      value: 1339762,
    },
    {
      title: "Ethiopia",
      id: "ET",
      color: "#de4c4f",
      continent: "africa",
      x: 958.694705985043,
      y: 62.983,
      value: 86538534,
    },
    {
      title: "Fiji",
      id: "FJ",
      color: "#8aabb0",
      continent: "australia",
      x: 4195.03497178682,
      y: 69.626,
      value: 875822,
    },
    {
      title: "Finland",
      id: "FI",
      color: "#d8854f",
      continent: "europe",
      x: 31551.9534459533,
      y: 80.362,
      value: 5402627,
    },
    {
      title: "France",
      id: "FR",
      color: "#d8854f",
      continent: "europe",
      x: 29896.4182238854,
      y: 81.663,
      value: 63457777,
    },
    {
      title: "Gabon",
      id: "GA",
      color: "#de4c4f",
      continent: "africa",
      x: 13853.4616556007,
      y: 63.115,
      value: 1563873,
    },
    {
      title: "Gambia",
      id: "GM",
      color: "#de4c4f",
      continent: "africa",
      x: 747.68096900917,
      y: 58.59,
      value: 1824777,
    },
    {
      title: "Georgia",
      id: "GE",
      color: "#d8854f",
      continent: "europe",
      x: 4943.23814339098,
      y: 74.162,
      value: 4304363,
    },
    {
      title: "Germany",
      id: "DE",
      color: "#d8854f",
      continent: "europe",
      x: 34131.8745974324,
      y: 80.578,
      value: 81990837,
    },
    {
      title: "Ghana",
      id: "GH",
      color: "#de4c4f",
      continent: "africa",
      x: 1728.47847396661,
      y: 60.979,
      value: 25545939,
    },
    {
      title: "Greece",
      id: "GR",
      color: "#d8854f",
      continent: "europe",
      x: 21811.3302462212,
      y: 80.593,
      value: 11418878,
    },
    {
      title: "Guatemala",
      id: "GT",
      color: "#a7a737",
      continent: "north_america",
      x: 5290.75202738533,
      y: 71.77,
      value: 15137569,
    },
    {
      title: "Guinea",
      id: "GN",
      color: "#de4c4f",
      continent: "africa",
      x: 965.699260160386,
      y: 55.865,
      value: 10480710,
    },
    {
      title: "Guinea-Bissau",
      id: "GW",
      color: "#de4c4f",
      continent: "africa",
      x: 593.074251034428,
      y: 54.054,
      value: 1579632,
    },
    {
      title: "Guyana",
      id: "GY",
      color: "#86a965",
      continent: "south_america",
      x: 4265.10644905906,
      y: 66.134,
      value: 757623,
    },
    {
      title: "Haiti",
      id: "HT",
      color: "#a7a737",
      continent: "north_america",
      x: 1180.36719611488,
      y: 62.746,
      value: 10255644,
    },
    {
      title: "Honduras",
      id: "HN",
      color: "#a7a737",
      continent: "north_america",
      x: 3615.1565803195,
      y: 73.503,
      value: 7912032,
    },
    {
      title: "Hong Kong, China",
      id: "HK",
      color: "#eea638",
      continent: "asia",
      x: 43854.4129062733,
      y: 83.199,
      value: 7196450,
    },
    {
      title: "Hungary",
      id: "HU",
      color: "#d8854f",
      continent: "europe",
      x: 17065.6047342876,
      y: 74.491,
      value: 9949589,
    },
    {
      title: "Iceland",
      id: "IS",
      color: "#d8854f",
      continent: "europe",
      x: 34371.1793657215,
      y: 81.96,
      value: 328290,
    },
    {
      title: "India",
      id: "IN",
      color: "#eea638",
      continent: "asia",
      x: 3229.14788745778,
      y: 66.168,
      value: 1258350971,
    },
    {
      title: "Indonesia",
      id: "ID",
      color: "#eea638",
      continent: "asia",
      x: 4379.69981934714,
      y: 70.624,
      value: 244769110,
    },
    {
      title: "Iran",
      id: "IR",
      color: "#eea638",
      continent: "asia",
      x: 12325.1280322371,
      y: 73.736,
      value: 75611798,
    },
    {
      title: "Iraq",
      id: "IQ",
      color: "#eea638",
      continent: "asia",
      x: 4160.84708826172,
      y: 69.181,
      value: 33703068,
    },
    {
      title: "Ireland",
      id: "IE",
      color: "#d8854f",
      continent: "europe",
      x: 35856.1099094562,
      y: 80.531,
      value: 4579498,
    },
    {
      title: "Israel",
      id: "IL",
      color: "#eea638",
      continent: "asia",
      x: 27321.205182135,
      y: 81.641,
      value: 7694670,
    },
    {
      title: "Italy",
      id: "IT",
      color: "#d8854f",
      continent: "europe",
      x: 25811.7393303661,
      y: 82.235,
      value: 60964145,
    },
    {
      title: "Jamaica",
      id: "JM",
      color: "#a7a737",
      continent: "north_america",
      x: 6945.70274711582,
      y: 73.338,
      value: 2761331,
    },
    {
      title: "Japan",
      id: "JP",
      color: "#eea638",
      continent: "asia",
      x: 31273.9932002261,
      y: 83.418,
      value: 126434653,
    },
    {
      title: "Jordan",
      id: "JO",
      color: "#eea638",
      continent: "asia",
      x: 5242.51826246118,
      y: 73.7,
      value: 6457260,
    },
    {
      title: "Kazakhstan",
      id: "KZ",
      color: "#eea638",
      continent: "asia",
      x: 11982.6526657273,
      y: 66.394,
      value: 16381297,
    },
    {
      title: "Kenya",
      id: "KE",
      color: "#de4c4f",
      continent: "africa",
      x: 1517.69754383602,
      y: 61.115,
      value: 42749418,
    },
    {
      title: "Korea, Dem. Rep.",
      id: "KP",
      color: "#eea638",
      continent: "asia",
      x: 1540.44018783769,
      y: 69.701,
      value: 24553672,
    },
    {
      title: "Korea, Rep.",
      id: "KR",
      color: "#eea638",
      continent: "asia",
      x: 26199.4035642374,
      y: 81.294,
      value: 48588326,
    },
    {
      title: "Kuwait",
      id: "KW",
      color: "#eea638",
      continent: "asia",
      x: 42045.05923634,
      y: 74.186,
      value: 2891553,
    },
    {
      title: "Kyrgyzstan",
      id: "KG",
      color: "#eea638",
      continent: "asia",
      x: 2078.20824171434,
      y: 67.37,
      value: 5448085,
    },
    {
      title: "Laos",
      id: "LA",
      color: "#eea638",
      continent: "asia",
      x: 2807.04752629832,
      y: 67.865,
      value: 6373934,
    },
    {
      title: "Latvia",
      id: "LV",
      color: "#d8854f",
      continent: "europe",
      x: 15575.2762808015,
      y: 72.045,
      value: 2234572,
    },
    {
      title: "Lebanon",
      id: "LB",
      color: "#eea638",
      continent: "asia",
      x: 13711.975683994,
      y: 79.716,
      value: 4291719,
    },
    {
      title: "Lesotho",
      id: "LS",
      color: "#de4c4f",
      continent: "africa",
      x: 1970.47114938861,
      y: 48.947,
      value: 2216850,
    },
    {
      title: "Liberia",
      id: "LR",
      color: "#de4c4f",
      continent: "africa",
      x: 499.809082037359,
      y: 60.23,
      value: 4244684,
    },
    {
      title: "Libya",
      id: "LY",
      color: "#de4c4f",
      continent: "africa",
      x: 9136.34462458268,
      y: 75.13,
      value: 6469497,
    },
    {
      title: "Lithuania",
      id: "LT",
      color: "#d8854f",
      continent: "europe",
      x: 18469.9748244583,
      y: 71.942,
      value: 3292454,
    },
    {
      title: "Macedonia, FYR",
      id: "MK",
      color: "#d8854f",
      continent: "europe",
      x: 8918.81131421927,
      y: 75.041,
      value: 2066785,
    },
    {
      title: "Madagascar",
      id: "MG",
      color: "#de4c4f",
      continent: "africa",
      x: 981.478674981018,
      y: 64.28,
      value: 21928518,
    },
    {
      title: "Malawi",
      id: "MW",
      color: "#de4c4f",
      continent: "africa",
      x: 848.191013907702,
      y: 54.798,
      value: 15882815,
    },
    {
      title: "Malaysia",
      id: "MY",
      color: "#eea638",
      continent: "asia",
      x: 14202.2119391177,
      y: 74.836,
      value: 29321798,
    },
    {
      title: "Mali",
      id: "ML",
      color: "#de4c4f",
      continent: "africa",
      x: 1070.55152828447,
      y: 54.622,
      value: 16318897,
    },
    {
      title: "Mauritania",
      id: "MR",
      color: "#de4c4f",
      continent: "africa",
      x: 1898.35192059663,
      y: 61.39,
      value: 3622961,
    },
    {
      title: "Mauritius",
      id: "MU",
      color: "#de4c4f",
      continent: "africa",
      x: 13082.7750766535,
      y: 73.453,
      value: 1313803,
    },
    {
      title: "Mexico",
      id: "MX",
      color: "#a7a737",
      continent: "north_america",
      x: 12030.3862129571,
      y: 77.281,
      value: 116146768,
    },
    {
      title: "Moldova",
      id: "MD",
      color: "#d8854f",
      continent: "europe",
      x: 2963.99305976246,
      y: 68.779,
      value: 3519266,
    },
    {
      title: "Mongolia",
      id: "MN",
      color: "#eea638",
      continent: "asia",
      x: 4300.13326887206,
      y: 67.286,
      value: 2844081,
    },
    {
      title: "Montenegro",
      id: "ME",
      color: "#d8854f",
      continent: "europe",
      x: 10064.1609429569,
      y: 74.715,
      value: 632796,
    },
    {
      title: "Morocco",
      id: "MA",
      color: "#de4c4f",
      continent: "africa",
      x: 4514.51993561297,
      y: 70.714,
      value: 32598536,
    },
    {
      title: "Mozambique",
      id: "MZ",
      color: "#de4c4f",
      continent: "africa",
      x: 1058.44192915498,
      y: 49.91,
      value: 24475186,
    },
    {
      title: "Myanmar",
      id: "MM",
      color: "#eea638",
      continent: "asia",
      x: 1657.04593430092,
      y: 65.009,
      value: 48724387,
    },
    {
      title: "Namibia",
      id: "NA",
      color: "#de4c4f",
      continent: "africa",
      x: 5535.83674233219,
      y: 64.014,
      value: 2364433,
    },
    {
      title: "Nepal",
      id: "NP",
      color: "#eea638",
      continent: "asia",
      x: 1264.49264527071,
      y: 67.989,
      value: 31011137,
    },
    {
      title: "Netherlands",
      id: "NL",
      color: "#d8854f",
      continent: "europe",
      x: 36257.0874018501,
      y: 80.906,
      value: 16714228,
    },
    {
      title: "New Zealand",
      id: "NZ",
      color: "#8aabb0",
      continent: "australia",
      x: 25223.5351395532,
      y: 80.982,
      value: 4461257,
    },
    {
      title: "Nicaragua",
      id: "NI",
      color: "#a7a737",
      continent: "north_america",
      x: 3098.48351674394,
      y: 74.515,
      value: 5954898,
    },
    {
      title: "Niger",
      id: "NE",
      color: "#de4c4f",
      continent: "africa",
      x: 706.79424834157,
      y: 57.934,
      value: 16644339,
    },
    {
      title: "Nigeria",
      id: "NG",
      color: "#de4c4f",
      continent: "africa",
      x: 2483.98940927953,
      y: 52.116,
      value: 166629383,
    },
    {
      title: "Norway",
      id: "NO",
      color: "#d8854f",
      continent: "europe",
      x: 47383.6245293861,
      y: 81.367,
      value: 4960482,
    },
    {
      title: "Oman",
      id: "OM",
      color: "#eea638",
      continent: "asia",
      x: 26292.8480723207,
      y: 76.287,
      value: 2904037,
    },
    {
      title: "Pakistan",
      id: "PK",
      color: "#eea638",
      continent: "asia",
      x: 2681.12078190231,
      y: 66.42,
      value: 179951140,
    },
    {
      title: "Panama",
      id: "PA",
      color: "#a7a737",
      continent: "north_america",
      x: 13607.1433621853,
      y: 77.342,
      value: 3624991,
    },
    {
      title: "Papua New Guinea",
      id: "PG",
      color: "#8aabb0",
      continent: "australia",
      x: 2391.5795121997,
      y: 62.288,
      value: 7170112,
    },
    {
      title: "Paraguay",
      id: "PY",
      color: "#86a965",
      continent: "south_america",
      x: 4467.15872465943,
      y: 72.181,
      value: 6682943,
    },
    {
      title: "Peru",
      id: "PE",
      color: "#86a965",
      continent: "south_america",
      x: 9277.57076044381,
      y: 74.525,
      value: 29733829,
    },
    {
      title: "Philippines",
      id: "PH",
      color: "#eea638",
      continent: "asia",
      x: 3677.10197520058,
      y: 68.538,
      value: 96471461,
    },
    {
      title: "Poland",
      id: "PL",
      color: "#d8854f",
      continent: "europe",
      x: 17851.9477668397,
      y: 76.239,
      value: 38317090,
    },
    {
      title: "Portugal",
      id: "PT",
      color: "#d8854f",
      continent: "europe",
      x: 19576.4108427574,
      y: 79.732,
      value: 10699333,
    },
    {
      title: "Romania",
      id: "RO",
      color: "#d8854f",
      continent: "europe",
      x: 11058.1809744544,
      y: 73.718,
      value: 21387517,
    },
    {
      title: "Russia",
      id: "RU",
      color: "#d8854f",
      continent: "europe",
      x: 15427.6167470064,
      y: 67.874,
      value: 142703181,
    },
    {
      title: "Rwanda",
      id: "RW",
      color: "#de4c4f",
      continent: "africa",
      x: 1223.52570881561,
      y: 63.563,
      value: 11271786,
    },
    {
      title: "Saudi Arabia",
      id: "SA",
      color: "#eea638",
      continent: "asia",
      x: 26259.6213479005,
      y: 75.264,
      value: 28705133,
    },
    {
      title: "Senegal",
      id: "SN",
      color: "#de4c4f",
      continent: "africa",
      x: 1753.48800936096,
      y: 63.3,
      value: 13107945,
    },
    {
      title: "Serbia",
      id: "RS",
      color: "#d8854f",
      continent: "europe",
      x: 9335.95911484282,
      y: 73.934,
      value: 9846582,
    },
    {
      title: "Sierra Leone",
      id: "SL",
      color: "#de4c4f",
      continent: "africa",
      x: 1072.95787930719,
      y: 45.338,
      value: 6126450,
    },
    {
      title: "Singapore",
      id: "SG",
      color: "#eea638",
      continent: "asia",
      x: 49381.9560054179,
      y: 82.155,
      value: 5256278,
    },
    {
      title: "Slovak Republic",
      id: "SK",
      color: "#d8854f",
      continent: "europe",
      x: 20780.9857840812,
      y: 75.272,
      value: 5480332,
    },
    {
      title: "Slovenia",
      id: "SI",
      color: "#d8854f",
      continent: "europe",
      x: 23986.8506836646,
      y: 79.444,
      value: 2040057,
    },
    {
      title: "Solomon Islands",
      id: "SB",
      color: "#8aabb0",
      continent: "australia",
      x: 2024.23067334134,
      y: 67.465,
      value: 566481,
    },
    {
      title: "Somalia",
      id: "SO",
      color: "#de4c4f",
      continent: "africa",
      x: 953.275713662563,
      y: 54,
      value: 9797445,
    },
    {
      title: "South Africa",
      id: "ZA",
      color: "#de4c4f",
      continent: "africa",
      x: 9657.25275417241,
      y: 56.271,
      value: 50738255,
    },
    {
      title: "South Sudan",
      id: "SS",
      color: "#de4c4f",
      continent: "africa",
      x: 1433.03720057714,
      y: 54.666,
      value: 10386101,
    },
    {
      title: "Spain",
      id: "ES",
      color: "#d8854f",
      continent: "europe",
      x: 26457.7572559653,
      y: 81.958,
      value: 46771596,
    },
    {
      title: "Sri Lanka",
      id: "LK",
      color: "#eea638",
      continent: "asia",
      x: 5182.66658831813,
      y: 74.116,
      value: 21223550,
    },
    {
      title: "Sudan",
      id: "SD",
      color: "#de4c4f",
      continent: "africa",
      x: 2917.61641581811,
      y: 61.875,
      value: 35335982,
    },
    {
      title: "Suriname",
      id: "SR",
      color: "#86a965",
      continent: "south_america",
      x: 8979.80549248675,
      y: 70.794,
      value: 534175,
    },
    {
      title: "Swaziland",
      id: "SZ",
      color: "#de4c4f",
      continent: "africa",
      x: 4979.704126513,
      y: 48.91,
      value: 1220408,
    },
    {
      title: "Sweden",
      id: "SE",
      color: "#d8854f",
      continent: "europe",
      x: 34530.2628238397,
      y: 81.69,
      value: 9495392,
    },
    {
      title: "Switzerland",
      id: "CH",
      color: "#d8854f",
      continent: "europe",
      x: 37678.3928108684,
      y: 82.471,
      value: 7733709,
    },
    {
      title: "Syria",
      id: "SY",
      color: "#eea638",
      continent: "asia",
      x: 4432.01553897559,
      y: 71,
      value: 21117690,
    },
    {
      title: "Taiwan",
      id: "TW",
      color: "#eea638",
      continent: "asia",
      x: 32840.8623523232,
      y: 79.45,
      value: 23114000,
    },
    {
      title: "Tajikistan",
      id: "TJ",
      color: "#eea638",
      continent: "asia",
      x: 1952.10042735043,
      y: 67.118,
      value: 7078755,
    },
    {
      title: "Tanzania",
      id: "TZ",
      color: "#de4c4f",
      continent: "africa",
      x: 1330.05614548839,
      y: 60.885,
      value: 47656367,
    },
    {
      title: "Thailand",
      id: "TH",
      color: "#eea638",
      continent: "asia",
      x: 8451.15964058768,
      y: 74.225,
      value: 69892142,
    },
    {
      title: "Timor-Leste",
      id: "TL",
      color: "#eea638",
      continent: "asia",
      x: 3466.08281224683,
      y: 67.033,
      value: 1187194,
    },
    {
      title: "Togo",
      id: "TG",
      color: "#de4c4f",
      continent: "africa",
      x: 975.396852535221,
      y: 56.198,
      value: 6283092,
    },
    {
      title: "Trinidad and Tobago",
      id: "TT",
      color: "#a7a737",
      continent: "north_america",
      x: 17182.0954558471,
      y: 69.761,
      value: 1350999,
    },
    {
      title: "Tunisia",
      id: "TN",
      color: "#de4c4f",
      continent: "africa",
      x: 7620.47056462131,
      y: 75.632,
      value: 10704948,
    },
    {
      title: "Turkey",
      id: "TR",
      color: "#d8854f",
      continent: "europe",
      x: 9287.29312549815,
      y: 74.938,
      value: 74508771,
    },
    {
      title: "Turkmenistan",
      id: "TM",
      color: "#eea638",
      continent: "asia",
      x: 7921.2740619558,
      y: 65.299,
      value: 5169660,
    },
    {
      title: "Uganda",
      id: "UG",
      color: "#de4c4f",
      continent: "africa",
      x: 1251.09807015907,
      y: 58.668,
      value: 35620977,
    },
    {
      title: "Ukraine",
      id: "UA",
      color: "#d8854f",
      continent: "europe",
      x: 6389.58597273257,
      y: 68.414,
      value: 44940268,
    },
    {
      title: "United Arab Emirates",
      id: "AE",
      color: "#eea638",
      continent: "asia",
      x: 31980.24143802,
      y: 76.671,
      value: 8105873,
    },
    {
      title: "United Kingdom",
      id: "GB",
      color: "#d8854f",
      continent: "europe",
      x: 31295.1431522074,
      y: 80.396,
      value: 62798099,
    },
    {
      title: "United States",
      id: "US",
      color: "#a7a737",
      continent: "north_america",
      x: 42296.2316492477,
      y: 78.797,
      value: 315791284,
    },
    {
      title: "Uruguay",
      id: "UY",
      color: "#86a965",
      continent: "south_america",
      x: 13179.2310803465,
      y: 77.084,
      value: 3391428,
    },
    {
      title: "Uzbekistan",
      id: "UZ",
      color: "#eea638",
      continent: "asia",
      x: 3117.27386553102,
      y: 68.117,
      value: 28077486,
    },
    {
      title: "Venezuela",
      id: "VE",
      color: "#86a965",
      continent: "south_america",
      x: 11685.1771941737,
      y: 74.477,
      value: 29890694,
    },
    {
      title: "West Bank and Gaza",
      id: "PS",
      color: "#eea638",
      continent: "asia",
      x: 4328.39115760087,
      y: 73.018,
      value: 4270791,
    },
    {
      title: "Vietnam",
      id: "VN",
      color: "#eea638",
      continent: "asia",
      x: 3073.64961158389,
      y: 75.793,
      value: 89730274,
    },
    {
      title: "Yemen, Rep.",
      id: "YE",
      color: "#eea638",
      continent: "asia",
      x: 2043.7877761328,
      y: 62.923,
      value: 25569263,
    },
    {
      title: "Zambia",
      id: "ZM",
      color: "#de4c4f",
      continent: "africa",
      x: 1550.92385858124,
      y: 57.037,
      value: 13883577,
    },
    {
      title: "Zimbabwe",
      id: "ZW",
      color: "#de4c4f",
      continent: "africa",
      x: 545.344601005788,
      y: 58.142,
      value: 13013678,
    },
  ];

  return chart;
}
